'use client';
import Image from 'next/image';
import { Check, Copy, ImagePlus, Receipt, Upload } from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  errorMessage,
  uploadReceipt,
  type ConnectedOrder,
  type PaymentMethod,
} from '@/lib/connected';
import { money } from '@/lib/storefront';

export const paymentLabels: Record<string, string> = {
  awaiting_receipt: 'Receipt needed',
  pending_review: 'Receipt under review',
  confirmed: 'Payment confirmed',
  needs_receipt: 'New receipt needed',
  not_required: 'Arrange with the shop',
};

function CopyValue({ value, label }: { value: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const [failed, setFailed] = useState(false);
  return (
    <div className="copy-value">
      <span className="copy-selectable">{value}</span>
      <button
        type="button"
        aria-label={`Copy ${label}`}
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(value);
            setCopied(true);
            setFailed(false);
          } catch {
            setFailed(true);
          }
        }}
      >
        {copied ? (
          <Check size={15} aria-hidden="true" />
        ) : (
          <Copy size={15} aria-hidden="true" />
        )}
        <small>{copied ? 'Copied' : 'Copy'}</small>
      </button>
      {failed && (
        <small className="copy-failure">
          Copy unavailable. Select the number to copy.
        </small>
      )}
    </div>
  );
}

export function PaymentDetails({
  method,
  total,
}: {
  method: Pick<
    PaymentMethod,
    | 'label'
    | 'bankName'
    | 'accountName'
    | 'accountNumber'
    | 'instructions'
    | 'qrImage'
  >;
  total?: number;
}) {
  return (
    <div className="payment-details">
      {method.qrImage && (
        <a
          className="payment-qr"
          href={method.qrImage}
          target="_blank"
          rel="noreferrer"
          aria-label={`Open ${method.label} QR image`}
        >
          <Image
            src={method.qrImage}
            width={220}
            height={220}
            unoptimized
            alt={`${method.label} payment QR`}
          />
          <span>Open QR image ↗</span>
        </a>
      )}
      <div className="payment-bank-details">
        <h3>{method.label}</h3>
        {method.bankName && (
          <p className="payment-bank-name">{method.bankName}</p>
        )}
        <dl>
          {method.accountName && (
            <div>
              <dt>Account name</dt>
              <dd>{method.accountName}</dd>
            </div>
          )}
          {method.accountNumber && (
            <div>
              <dt>Account number</dt>
              <dd>
                <CopyValue
                  value={method.accountNumber}
                  label="account number"
                />
              </dd>
            </div>
          )}
          {total !== undefined && (
            <div>
              <dt>Items total</dt>
              <dd>
                <CopyValue value={String(total)} label="items total" />
                <strong className="payment-formatted-total">
                  {money(total)}
                </strong>
              </dd>
            </div>
          )}
        </dl>
        {method.instructions && (
          <p className="payment-note">{method.instructions}</p>
        )}
      </div>
    </div>
  );
}

export function ReceiptUpload({
  order,
  csrf,
  onUpdated,
}: {
  order: ConnectedOrder;
  csrf: string | null;
  onUpdated: (order: ConnectedOrder) => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    // oxlint-disable-next-line react/react-compiler -- A selected file needs a blob URL that is revoked when replaced or unmounted.
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  const canUpload =
    order.status !== 'cancelled' &&
    order.status !== 'completed' &&
    (order.paymentStatus === 'awaiting_receipt' ||
      order.paymentStatus === 'needs_receipt');
  return (
    <div className="receipt-section">
      {order.paymentReviewNote && (
        <p className="receipt-review-note">
          <strong>Note from SPL</strong>
          {order.paymentReviewNote}
        </p>
      )}
      {order.receipt && (
        <a
          className="receipt-existing"
          href={order.receipt.imageUrl}
          target="_blank"
          rel="noreferrer"
        >
          <Receipt size={18} aria-hidden="true" />
          <span>
            View uploaded receipt
            <small>{new Date(order.receipt.uploadedAt).toLocaleString()}</small>
          </span>
          <span aria-hidden="true">↗</span>
        </a>
      )}
      {canUpload && (
        <form
          className="portal-form receipt-upload"
          onSubmit={async (event) => {
            event.preventDefault();
            if (!file || busy) return;
            setBusy(true);
            setError('');
            try {
              const result = await uploadReceipt(order.id, file, csrf);
              onUpdated(result.order);
              setFile(null);
              setPreview('');
            } catch (cause) {
              setError(errorMessage(cause));
            } finally {
              setBusy(false);
            }
          }}
        >
          <label className="receipt-picker">
            <ImagePlus size={22} aria-hidden="true" />
            <span>
              {file
                ? file.name
                : order.paymentStatus === 'needs_receipt'
                  ? 'Choose a new receipt photo'
                  : 'Choose your receipt photo'}
              <small>JPG, PNG or WebP · up to 3 MB</small>
            </span>
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              disabled={busy}
              onChange={(event) => {
                const picked = event.target.files?.[0];
                if (!picked) return;
                setError('');
                if (
                  !['image/jpeg', 'image/png', 'image/webp'].includes(
                    picked.type,
                  ) ||
                  picked.size > 3 * 1024 * 1024
                ) {
                  setError('Choose a JPG, PNG or WebP photo up to 3 MB.');
                  event.target.value = '';
                  setFile(null);
                  setPreview('');
                  return;
                }
                setFile(picked);
              }}
            />
          </label>
          {file && preview && (
            <Image
              className="receipt-preview"
              src={preview}
              width={400}
              height={400}
              unoptimized
              alt="Receipt preview before upload"
            />
          )}
          <button className="portal-primary" disabled={!file || busy}>
            <Upload size={16} aria-hidden="true" />
            {busy ? 'Uploading receipt…' : 'Send receipt to SPL'}
          </button>
          <p className="portal-muted">
            Include the amount and transaction reference. SPL will check the
            receipt before confirming payment.
          </p>
        </form>
      )}
      {error && (
        <p className="portal-error" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function OrderPayment({
  order,
  csrf,
  onUpdated,
}: {
  order: ConnectedOrder;
  csrf: string | null;
  onUpdated: (order: ConnectedOrder) => void;
}) {
  return (
    <section className="order-payment" aria-label="Payment details">
      <div className="portal-order-heading">
        <h3>Payment</h3>
        <span className={`order-status payment-${order.paymentStatus}`}>
          {paymentLabels[order.paymentStatus] ?? order.paymentStatus}
        </span>
      </div>
      {order.status === 'cancelled' ? (
        <p>
          This order was cancelled. Contact SPL if you already sent a payment.
        </p>
      ) : order.paymentMethod ? (
        <>
          {order.paymentStatus === 'awaiting_receipt' ||
          order.paymentStatus === 'needs_receipt' ? (
            <p>
              Pay using the details below, then send your receipt. Include your
              order number in the transfer note where possible.
            </p>
          ) : order.paymentStatus === 'pending_review' ? (
            <p>
              Receipt received. SPL will check it and update your payment status
              here.
            </p>
          ) : order.paymentStatus === 'confirmed' ? (
            <p>
              SPL has confirmed your payment. Your order status is shown above.
            </p>
          ) : null}
          <details
            className="payment-snapshot"
            open={
              order.paymentStatus === 'awaiting_receipt' ||
              order.paymentStatus === 'needs_receipt'
            }
          >
            <summary>Bank / wallet details</summary>
            <PaymentDetails method={order.paymentMethod} total={order.total} />
            <p className="portal-muted">
              Items total excludes delivery. Confirm any delivery charge with
              SPL before transferring.
            </p>
          </details>
          <ReceiptUpload order={order} csrf={csrf} onUpdated={onUpdated} />
        </>
      ) : (
        <p>Contact SPL to arrange payment for this order.</p>
      )}
    </section>
  );
}

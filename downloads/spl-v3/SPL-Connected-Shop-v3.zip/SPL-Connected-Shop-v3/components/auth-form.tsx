'use client';
import { useState } from 'react';
import { api, errorMessage, type Session } from '@/lib/connected';
export function AuthForm({
  owner = false,
  onSignedIn,
}: {
  owner?: boolean;
  onSignedIn: (session: Session) => void;
}) {
  const [register, setRegister] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  return (
    <section className="auth-card">
      <span className="eyebrow">
        {owner ? 'OWNER ACCESS' : 'CUSTOMER ACCOUNT'}
      </span>
      <h2>
        {register
          ? 'Create your account'
          : owner
            ? 'Sign in to your shop'
            : 'Sign in to continue'}
      </h2>
      <p>
        {owner
          ? 'Manage products and orders. Owner accounts are created by the shop administrator.'
          : 'Your orders stay connected to your account across devices.'}
      </p>
      <form
        onSubmit={async (event) => {
          event.preventDefault();
          if (busy) return;
          setBusy(true);
          setError('');
          try {
            const session = await api<Session>(
              `/api/auth/${register ? 'register' : 'login'}`,
              {
                method: 'POST',
                body: { email, password, ...(register ? { name } : {}) },
              },
            );
            setPassword('');
            onSignedIn(session);
          } catch (e) {
            setError(errorMessage(e));
          } finally {
            setBusy(false);
          }
        }}
      >
        {register && (
          <label>
            Full name
            <input
              autoComplete="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              minLength={2}
              maxLength={80}
            />
          </label>
        )}
        <label>
          Email address
          <input
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            maxLength={254}
          />
        </label>
        <label>
          Password
          <input
            type="password"
            autoComplete={register ? 'new-password' : 'current-password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={register ? 12 : undefined}
            maxLength={128}
          />
        </label>
        {register && <small>Use at least 12 characters.</small>}
        {error && (
          <p role="alert" className="portal-error">
            {error}
          </p>
        )}
        <button className="portal-primary" disabled={busy}>
          {busy ? 'Please wait…' : register ? 'Create account' : 'Sign in'}
        </button>
      </form>
      {!owner && (
        <button
          className="portal-link"
          onClick={() => {
            setRegister(!register);
            setError('');
            setPassword('');
          }}
        >
          {register
            ? 'Already registered? Sign in'
            : 'New customer? Create an account'}
        </button>
      )}
    </section>
  );
}

import { createInterface } from 'node:readline/promises';
import { emitKeypressEvents } from 'node:readline';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { loadRuntimeEnvironment } from '../server/environment.mjs';
import { createStore } from '../server/store.mjs';
const root = fileURLToPath(new URL('../', import.meta.url));
loadRuntimeEnvironment(root);
function secretPrompt() {
  return new Promise((resolve, reject) => {
    if (!process.stdin.isTTY)
      return reject(
        new Error(
          'Run this command in a terminal, or provide OWNER_EMAIL, OWNER_NAME and OWNER_PASSWORD securely through environment variables.',
        ),
      );
    let value = '';
    process.stdout.write('Owner password (at least 12 characters): ');
    emitKeypressEvents(process.stdin);
    process.stdin.setRawMode(true);
    process.stdin.resume();
    const finish = (error) => {
      process.stdin.off('keypress', handler);
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdout.write('\n');
      if (error) reject(error);
      else resolve(value);
    };
    const handler = (str, key) => {
      if (key?.ctrl && key.name === 'c') return finish(new Error('Cancelled.'));
      if (key?.name === 'return') return finish();
      if (key?.name === 'backspace') {
        if (value.length) {
          value = value.slice(0, -1);
          process.stdout.write('\b \b');
        }
        return;
      }
      if (str && !key?.ctrl && !key?.meta && !str.includes('\u001b')) {
        value += str;
        process.stdout.write('*');
      }
    };
    process.stdin.on('keypress', handler);
  });
}
let email = process.env.OWNER_EMAIL;
let name = process.env.OWNER_NAME;
let password = process.env.OWNER_PASSWORD;
try {
  if (!email || !name) {
    const prompt = createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    try {
      email ??= await prompt.question('Owner email: ');
      name ??= await prompt.question('Owner name: ');
    } finally {
      prompt.close();
    }
  }
  password ??= await secretPrompt();
  const store = createStore(
    path.join(
      path.resolve(process.env.DATA_DIRECTORY ?? path.join(root, 'data')),
      'shop.sqlite',
    ),
  );
  try {
    store.createUser({ email, name, password }, 'owner');
    console.log('Owner account created. Sign in at /owner/.');
  } finally {
    store.close();
  }
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}

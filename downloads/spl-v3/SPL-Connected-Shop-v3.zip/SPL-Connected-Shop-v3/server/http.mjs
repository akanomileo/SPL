import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { createStore, HttpError } from './store.mjs';

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.rsc': 'text/x-component',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml',
  '.ico': 'image/x-icon',
};
const json = (res, status, body) => {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(body));
};
const fail = (status, message) => {
  throw new HttpError(status, message);
};
async function readBody(req, max = 64 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > max) fail(413, 'Request is too large.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}
async function readJson(req) {
  if (!String(req.headers['content-type'] ?? '').startsWith('application/json'))
    fail(415, 'JSON content required.');
  try {
    const body = JSON.parse((await readBody(req)).toString());
    if (!body || typeof body !== 'object' || Array.isArray(body))
      fail(400, 'Invalid JSON request.');
    return body;
  } catch (error) {
    if (error instanceof HttpError) throw error;
    fail(400, 'Invalid JSON request.');
  }
}
const equal = (a, b) =>
  typeof a === 'string' &&
  typeof b === 'string' &&
  Buffer.byteLength(a) === Buffer.byteLength(b) &&
  timingSafeEqual(Buffer.from(a), Buffer.from(b));
const getToken = (req) =>
  String(req.headers.cookie ?? '')
    .split(';')
    .map((s) => s.trim())
    .find((s) => s.startsWith('spl_session='))
    ?.slice(12);

export function createBackend({
  databasePath,
  staticDirectory,
  uploadDirectory,
  allowedOrigins,
  secureCookies = false,
}) {
  const store = createStore(databasePath);
  const rates = new Map();
  const cookie = (res, token, maxAge = 604800) =>
    res.setHeader(
      'Set-Cookie',
      `spl_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secureCookies ? '; Secure' : ''}`,
    );
  const server = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    try {
      const requestUrl = new URL(req.url, 'http://local');
      const pathname = decodeURIComponent(requestUrl.pathname);
      if (pathname.startsWith('/api/')) {
        const token = getToken(req);
        const session = store.session(token);
        if (
          !['GET', 'HEAD'].includes(req.method) &&
          !allowedOrigins.includes(req.headers.origin)
        )
          fail(403, 'Request origin is not allowed.');
        const authenticated = () => {
          if (!session) fail(401, 'Please sign in.');
          return session.user;
        };
        const owner = () => {
          const user = authenticated();
          if (user.role !== 'owner') fail(403, 'Owner access required.');
          return user;
        };
        const mutation = () => {
          const user = authenticated();
          if (!equal(req.headers['x-csrf-token'], session.csrf))
            fail(403, 'Session validation failed. Refresh and try again.');
          return user;
        };
        if (pathname === '/api/health' && req.method === 'GET')
          return json(res, 200, { ok: true });
        if (pathname === '/api/catalog' && req.method === 'GET')
          return json(res, 200, { products: store.catalog() });
        if (pathname === '/api/auth/session' && req.method === 'GET')
          return json(res, 200, {
            user: session?.user ?? null,
            csrf: session?.csrf ?? null,
          });
        if (
          ['/api/auth/login', '/api/auth/register'].includes(pathname) &&
          req.method === 'POST'
        ) {
          const ip = req.socket.remoteAddress;
          const now = Date.now();
          if (rates.size > 2000) {
            for (const [key, entry] of rates)
              if (entry.until <= now) rates.delete(key);
            if (rates.size > 2000) fail(429, 'Please try again later.');
          }
          const rate = rates.get(ip) ?? { count: 0, until: now + 15 * 60_000 };
          if (rate.until <= now) {
            rate.count = 0;
            rate.until = now + 15 * 60_000;
          }
          rate.count++;
          rates.set(ip, rate);
          if (rate.count > 30)
            fail(
              429,
              'Too many sign-in attempts. Please try again in 15 minutes.',
            );
          const body = await readJson(req);
          if (body.role && body.role !== 'customer')
            fail(
              403,
              'Owner accounts can only be created by the shop administrator.',
            );
          const user = pathname.endsWith('/register')
            ? store.createUser(body)
            : store.authenticate(body.email, body.password);
          store.revokeSession(token);
          const auth = store.newSession(user.id);
          cookie(res, auth.token);
          return json(res, 200, { user, csrf: auth.csrf });
        }
        if (pathname === '/api/auth/logout' && req.method === 'POST') {
          mutation();
          store.revokeSession(token);
          cookie(res, '', 0);
          return json(res, 200, { ok: true });
        }
        if (pathname === '/api/orders' && req.method === 'GET') {
          const user = authenticated();
          if (user.role !== 'customer') fail(403, 'Customer access required.');
          return json(res, 200, { orders: store.orders(user) });
        }
        if (pathname === '/api/orders' && req.method === 'POST') {
          const user = mutation();
          const result = store.placeOrder(
            user,
            await readJson(req),
            req.headers['idempotency-key'],
          );
          return json(res, 201, { order: result });
        }
        if (pathname === '/api/owner/products' && req.method === 'GET') {
          owner();
          return json(res, 200, { products: store.catalog(true) });
        }
        if (pathname === '/api/owner/products' && req.method === 'POST') {
          mutation();
          owner();
          return json(res, 201, {
            product: store.saveProduct(null, await readJson(req)),
          });
        }
        const productMatch = pathname.match(/^\/api\/owner\/products\/(\d+)$/);
        if (productMatch && req.method === 'PUT') {
          mutation();
          owner();
          return json(res, 200, {
            product: store.saveProduct(
              Number(productMatch[1]),
              await readJson(req),
            ),
          });
        }
        if (pathname === '/api/owner/orders' && req.method === 'GET') {
          return json(res, 200, { orders: store.orders(owner()) });
        }
        const orderMatch = pathname.match(
          /^\/api\/owner\/orders\/(SPL-[A-F0-9-]+)$/,
        );
        if (orderMatch && req.method === 'PUT') {
          mutation();
          const user = owner();
          return json(res, 200, {
            order: store.changeStatus(user, orderMatch[1], await readJson(req)),
          });
        }
        if (pathname === '/api/owner/images' && req.method === 'POST') {
          mutation();
          owner();
          const bytes = await readBody(req, 3 * 1024 * 1024);
          let ext;
          if (
            bytes.length >= 24 &&
            bytes
              .subarray(0, 8)
              .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
          )
            ext = 'png';
          else if (
            bytes.length >= 4 &&
            bytes[0] === 255 &&
            bytes[1] === 216 &&
            bytes[2] === 255
          )
            ext = 'jpg';
          else if (
            bytes.length >= 12 &&
            bytes.subarray(0, 4).toString() === 'RIFF' &&
            bytes.subarray(8, 12).toString() === 'WEBP'
          )
            ext = 'webp';
          else fail(400, 'Choose a JPG, PNG or WebP image, up to 3 MB.');
          fs.mkdirSync(uploadDirectory, { recursive: true, mode: 0o700 });
          const name = `${randomUUID()}.${ext}`;
          fs.writeFileSync(path.join(uploadDirectory, name), bytes, {
            mode: 0o600,
          });
          return json(res, 201, { image: `/uploads/${name}` });
        }
        fail(404, 'API endpoint not found.');
      }
      if (!['GET', 'HEAD'].includes(req.method))
        fail(405, 'Method not allowed.');
      let file;
      let root;
      if (/^\/uploads\/[a-f0-9-]+\.(?:jpg|png|webp)$/.test(pathname)) {
        root = path.resolve(uploadDirectory);
        file = path.join(root, path.basename(pathname));
      } else {
        root = path.resolve(staticDirectory);
        file = path.resolve(root, '.' + pathname);
        if (!file.startsWith(root + path.sep) && file !== root)
          fail(404, 'Not found.');
        if (fs.existsSync(file) && fs.statSync(file).isDirectory())
          file = path.join(file, 'index.html');
        if (
          !fs.existsSync(file) &&
          !path.extname(file) &&
          fs.existsSync(file + '.html')
        )
          file += '.html';
      }
      if (
        (req.headers.rsc === '1' || requestUrl.searchParams.has('_rsc')) &&
        file.endsWith('.html')
      )
        file = fs.existsSync(file.slice(0, -5) + '.txt')
          ? file.slice(0, -5) + '.txt'
          : file.slice(0, -5) + '.rsc';
      if (
        !file.startsWith(root + path.sep) ||
        !fs.existsSync(file) ||
        !fs.statSync(file).isFile()
      )
        fail(404, 'Not found.');
      res.writeHead(200, {
        'Content-Type': /(?:index|account|owner)\.txt$/.test(file)
          ? 'text/x-component'
          : (mime[path.extname(file)] ?? 'application/octet-stream'),
        'Cache-Control': pathname.startsWith('/_next/')
          ? 'public, max-age=31536000, immutable'
          : 'no-cache',
      });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).pipe(res);
    } catch (error) {
      if (!res.headersSent)
        json(res, error instanceof HttpError ? error.status : 500, {
          error:
            error instanceof HttpError
              ? error.message
              : 'Server error. Please try again.',
        });
      else res.end();
    }
  });
  server.requestTimeout = 30_000;
  server.headersTimeout = 15_000;
  return { server, store };
}

import type { Product } from './catalog';
import type { Delivery, RequestItem } from './storefront';
export type User = {
  id: string;
  name: string;
  email: string;
  role: 'customer' | 'owner';
};
export type Session = { user: User | null; csrf: string | null };
export type ManagedProduct = Product & { active: boolean; version: number };
export type ConnectedOrder = {
  id: string;
  customerId: string;
  customerName?: string;
  customerEmail?: string;
  items: RequestItem[];
  delivery: Delivery;
  payment: string;
  total: number;
  status: string;
  createdAt: string;
  updatedAt: string;
  version: number;
  events: { status: string; createdAt: string }[];
};
export const orderTransitions: Record<string, string[]> = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['ready', 'cancelled'],
  ready: ['completed', 'cancelled'],
  completed: [],
  cancelled: [],
};
export const paymentOptions = [
  'Discuss with the shop',
  'KPay',
  'Bank transfer',
  'Cash on delivery — subject to location',
];
export async function api<T>(
  path: string,
  options: {
    method?: string;
    body?: unknown;
    csrf?: string | null;
    key?: string;
  } = {},
): Promise<T> {
  const headers: Record<string, string> = {};
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';
  if (options.csrf) headers['X-CSRF-Token'] = options.csrf;
  if (options.key) headers['Idempotency-Key'] = options.key;
  const response = await fetch(path, {
    method: options.method ?? 'GET',
    credentials: 'same-origin',
    cache: 'no-store',
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  const data = await response
    .json()
    .catch(() => ({ error: 'The server did not return a valid response.' }));
  if (!response.ok) throw new Error(data.error ?? 'Please try again.');
  return data as T;
}
export const errorMessage = (error: unknown) =>
  error instanceof Error
    ? error.message
    : 'Something went wrong. Please try again.';

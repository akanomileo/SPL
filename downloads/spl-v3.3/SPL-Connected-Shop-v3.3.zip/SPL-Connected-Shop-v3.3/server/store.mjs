import { DatabaseSync } from 'node:sqlite';
import {
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
  createHash,
} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { products as seedProducts } from '../lib/catalog.ts';

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const fail = (status, message) => {
  throw new HttpError(status, message);
};
const text = (value, min, max, label) => {
  if (
    typeof value !== 'string' ||
    value.trim().length < min ||
    value.trim().length > max
  )
    fail(400, `${label} must be ${min}–${max} characters.`);
  return value.trim();
};
const integer = (value, min, max, label) => {
  if (!Number.isSafeInteger(value) || value < min || value > max)
    fail(400, `${label} is invalid.`);
  return value;
};
export const statuses = [
  'pending',
  'confirmed',
  'ready',
  'completed',
  'cancelled',
];
export const nextStatuses = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['ready', 'cancelled'],
  ready: ['completed', 'cancelled'],
  completed: [],
  cancelled: [],
};
export const payments = [
  'Discuss with the shop',
  'KPay',
  'Bank transfer',
  'Cash on delivery — subject to location',
];
export const digest = (value) =>
  createHash('sha256').update(value).digest('hex');
export function validateEmail(value) {
  const email = text(value, 5, 254, 'Email').toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    fail(400, 'Enter a valid email address.');
  return email;
}
function passwordHash(password, salt = randomBytes(16).toString('hex')) {
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
}
function passwordMatches(password, saved) {
  const [salt, hash] = saved.split(':');
  return timingSafeEqual(
    scryptSync(password, salt, 64),
    Buffer.from(hash, 'hex'),
  );
}
const userView = (u) => ({
  id: u.id,
  name: u.name,
  email: u.email,
  role: u.role,
});
const productView = (row) => ({
  ...JSON.parse(row.details),
  id: row.id,
  stock: row.stock,
  price: row.price,
  active: Boolean(row.active),
  version: row.version,
});
export function validateProduct(body) {
  const name = text(body.name, 3, 120, 'Product name');
  const subtitle = text(body.subtitle, 1, 180, 'Subtitle');
  const category = text(body.category, 2, 40, 'Category');
  const condition = text(body.condition, 2, 100, 'Condition');
  const price = integer(body.price, 1, 1_000_000_000_000, 'Price');
  const stock = integer(body.stock, 0, 1_000_000, 'Stock');
  const image = text(body.image, 1, 250, 'Image');
  if (
    !/^\/(?:products|uploads)\/[A-Za-z0-9_-]+\.(?:jpg|jpeg|png|webp)$/.test(
      image,
    )
  )
    fail(400, 'Use an uploaded image or a local product image.');
  if (
    !Array.isArray(body.specs) ||
    body.specs.length < 1 ||
    body.specs.length > 15
  )
    fail(400, 'Add 1–15 specifications.');
  const specs = body.specs.map((s) => text(s, 1, 160, 'Specification'));
  if (typeof body.active !== 'boolean')
    fail(400, 'Choose whether the product is visible.');
  const oldPrice =
    body.oldPrice == null
      ? undefined
      : integer(body.oldPrice, price + 1, 1_000_000_000_000, 'Previous price');
  return {
    name,
    subtitle,
    category,
    condition,
    price,
    stock,
    image,
    specs,
    oldPrice,
    active: body.active,
  };
}
function validateDelivery(body) {
  if (!body || typeof body !== 'object')
    fail(400, 'Delivery details are required.');
  const name = text(body.name, 2, 80, 'Full name');
  const phone = text(body.phone, 7, 80, 'Phone')
    .replace(/[၀-၉]/g, (d) => String(d.charCodeAt(0) - 0x1040))
    .replace(/[\s()+-]/g, '');
  if (!/^\d{7,15}$/.test(phone)) fail(400, 'Enter a valid phone number.');
  return {
    name,
    phone,
    address: text(body.address, 8, 300, 'Address'),
    note: text(body.note ?? '', 0, 300, 'Note'),
  };
}

export function createStore(filename) {
  if (filename !== ':memory:') {
    fs.mkdirSync(path.dirname(filename), { recursive: true, mode: 0o700 });
  }
  const db = new DatabaseSync(filename);
  if (filename !== ':memory:') fs.chmodSync(filename, 0o600);
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=10000;
    CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('owner','customer')), password_hash TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), csrf TEXT NOT NULL, expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT, details TEXT NOT NULL, price INTEGER NOT NULL, stock INTEGER NOT NULL CHECK(stock >= 0), active INTEGER NOT NULL, version INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY, customer_id TEXT NOT NULL REFERENCES users(id), items TEXT NOT NULL, delivery TEXT NOT NULL, payment TEXT NOT NULL, total INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, idempotency_key TEXT NOT NULL, request_hash TEXT NOT NULL, UNIQUE(customer_id,idempotency_key));
    CREATE TABLE IF NOT EXISTS order_events(id INTEGER PRIMARY KEY AUTOINCREMENT, order_id TEXT NOT NULL REFERENCES orders(id), actor_id TEXT NOT NULL REFERENCES users(id), status TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS orders_customer ON orders(customer_id);
    CREATE TABLE IF NOT EXISTS owner_setup(id INTEGER PRIMARY KEY CHECK(id=1), subject TEXT, setup_hash TEXT, expires_at INTEGER);
    INSERT OR IGNORE INTO owner_setup(id) VALUES(1);
    CREATE TABLE IF NOT EXISTS pending_google_migrations(user_id TEXT PRIMARY KEY REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS google_identities(subject TEXT PRIMARY KEY, user_id TEXT UNIQUE NOT NULL REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS google_flows(state_hash TEXT PRIMARY KEY, binding_hash TEXT NOT NULL, details TEXT NOT NULL, expires_at INTEGER NOT NULL);`);
  if (
    !db
      .prepare('PRAGMA table_info(sessions)')
      .all()
      .some((column) => column.name === 'auth_provider')
  )
    db.exec(
      "ALTER TABLE sessions ADD COLUMN auth_provider TEXT NOT NULL DEFAULT 'password'",
    );
  const transaction = (fn) => {
    db.exec('BEGIN IMMEDIATE');
    try {
      const value = fn();
      db.exec('COMMIT');
      return value;
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  };
  transaction(() => {
    if (
      db.prepare('SELECT COUNT(*) AS count FROM products').get().count === 0
    ) {
      const insert = db.prepare(
        'INSERT INTO products(id,details,price,stock,active) VALUES(?,?,?,?,1)',
      );
      for (const p of seedProducts)
        insert.run(p.id, JSON.stringify(p), p.price, p.stock);
    }
  });
  const dummyHash = passwordHash(randomBytes(32).toString('hex'));
  const orderView = (row) => ({
    id: row.id,
    customerId: row.customer_id,
    customerName: row.customer_name,
    customerEmail: row.customer_email,
    items: JSON.parse(row.items),
    delivery: JSON.parse(row.delivery),
    payment: row.payment,
    total: row.total,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    version: row.version,
    events: db
      .prepare(
        'SELECT status, created_at AS createdAt FROM order_events WHERE order_id=? ORDER BY id',
      )
      .all(row.id),
  });
  return {
    db,
    close: () => db.close(),
    createUser(body, role = 'customer') {
      const email = validateEmail(body.email);
      const name = text(body.name, 2, 80, 'Name');
      const password = typeof body.password === 'string' ? body.password : '';
      if (password.length < 12 || password.length > 128)
        fail(400, 'Use a password of 12–128 characters.');
      if (db.prepare('SELECT id FROM users WHERE email=?').get(email))
        fail(409, 'An account with that email already exists.');
      const user = { id: randomUUID(), name, email, role };
      db.prepare(
        'INSERT INTO users(id,email,name,role,password_hash) VALUES(?,?,?,?,?)',
      ).run(user.id, email, name, role, passwordHash(password));
      return user;
    },
    authenticate(emailValue, password) {
      const email = validateEmail(emailValue);
      if (typeof password !== 'string' || password.length > 128)
        fail(401, 'Email or password is incorrect.');
      const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
      const match = passwordMatches(password, u?.password_hash ?? dummyHash);
      if (!u || !match) fail(401, 'Email or password is incorrect.');
      return userView(u);
    },
    saveGoogleFlow(state, binding, details) {
      db.prepare('DELETE FROM google_flows WHERE expires_at<=?').run(
        Date.now(),
      );
      if (db.prepare('SELECT COUNT(*) AS n FROM google_flows').get().n >= 2000)
        fail(429, 'Please try signing in later.');
      db.prepare('INSERT INTO google_flows VALUES(?,?,?,?)').run(
        digest(state),
        digest(binding),
        JSON.stringify(details),
        Date.now() + 10 * 60_000,
      );
    },
    consumeGoogleFlow(state, binding) {
      if (
        typeof state !== 'string' ||
        state.length > 200 ||
        typeof binding !== 'string' ||
        binding.length > 200
      )
        fail(401, 'Google sign-in expired. Please try again.');
      return transaction(() => {
        const flow = db
          .prepare('SELECT * FROM google_flows WHERE state_hash=?')
          .get(digest(state));
        if (
          !flow ||
          flow.expires_at <= Date.now() ||
          flow.binding_hash !== digest(binding)
        )
          fail(401, 'Google sign-in expired. Please try again.');
        db.prepare('DELETE FROM google_flows WHERE state_hash=?').run(
          digest(state),
        );
        return JSON.parse(flow.details);
      });
    },
    ownerInfo() {
      const row = db.prepare('SELECT * FROM owner_setup WHERE id=1').get();
      return {
        configured: Boolean(row.subject),
        pending: Boolean(
          !row.subject && row.setup_hash && row.expires_at > Date.now(),
        ),
      };
    },
    isCurrentOwner(userId) {
      return Boolean(
        db
          .prepare(
            'SELECT 1 FROM google_identities g JOIN owner_setup o ON o.subject=g.subject WHERE o.id=1 AND g.user_id=?',
          )
          .get(userId),
      );
    },
    createOwnerSetup(replace = false) {
      return transaction(() => {
        const row = db.prepare('SELECT * FROM owner_setup WHERE id=1').get();
        if (row.subject && !replace)
          fail(
            409,
            'An owner is already configured. Use --replace only to intentionally change the owner account.',
          );
        const code = randomBytes(32).toString('base64url');
        db.prepare(
          'UPDATE owner_setup SET subject=NULL, setup_hash=?, expires_at=? WHERE id=1',
        ).run(digest(code), Date.now() + 24 * 60 * 60_000);
        db.exec(
          "DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE role='owner'); UPDATE users SET role='customer' WHERE role='owner';",
        );
        return code;
      });
    },
    validateOwnerSetup(code) {
      const row = db.prepare('SELECT * FROM owner_setup WHERE id=1').get();
      if (
        row.subject ||
        !row.setup_hash ||
        row.expires_at <= Date.now() ||
        typeof code !== 'string' ||
        code.length > 200 ||
        digest(code) !== row.setup_hash
      )
        fail(403, 'The private owner setup code is invalid or expired.');
      return row.setup_hash;
    },
    authorizeGoogleMigration(email) {
      const user = db
        .prepare('SELECT id FROM users WHERE email=?')
        .get(validateEmail(email));
      if (!user) fail(404, 'No existing account uses that email.');
      db.prepare(
        'INSERT OR IGNORE INTO pending_google_migrations(user_id) VALUES(?)',
      ).run(user.id);
    },
    googleUser(
      identity,
      { audience = 'customer', ownerSetupHash = null } = {},
    ) {
      return transaction(() => {
        const binding = db
          .prepare('SELECT * FROM owner_setup WHERE id=1')
          .get();
        let approvedOwner = binding.subject === identity.subject;
        if (audience === 'owner' && !approvedOwner) {
          if (
            binding.subject ||
            !ownerSetupHash ||
            binding.setup_hash !== ownerSetupHash ||
            binding.expires_at <= Date.now()
          )
            fail(
              403,
              'Only the configured Google owner account can access this dashboard.',
            );
          db.prepare(
            'UPDATE owner_setup SET subject=?,setup_hash=NULL,expires_at=NULL WHERE id=1',
          ).run(identity.subject);
          approvedOwner = true;
        }
        const role = approvedOwner ? 'owner' : 'customer';
        let user = db
          .prepare(
            'SELECT u.* FROM users u JOIN google_identities g ON g.user_id=u.id WHERE g.subject=?',
          )
          .get(identity.subject);
        if (user) {
          if (
            user.email !== identity.email &&
            db
              .prepare('SELECT id FROM users WHERE email=? AND id<>?')
              .get(identity.email, user.id)
          )
            fail(
              409,
              'Your changed Google email conflicts with an existing account. Contact the shop.',
            );
          if (user.role !== role)
            db.prepare('DELETE FROM sessions WHERE user_id=?').run(user.id);
          db.prepare('UPDATE users SET email=?,role=? WHERE id=?').run(
            identity.email,
            role,
            user.id,
          );
          return { ...userView(user), email: identity.email, role };
        }
        user = db
          .prepare('SELECT * FROM users WHERE email=?')
          .get(identity.email);
        if (user) {
          if (
            !approvedOwner &&
            !db
              .prepare(
                'SELECT 1 FROM pending_google_migrations WHERE user_id=?',
              )
              .get(user.id)
          )
            fail(
              409,
              'This email has an older password account. Ask the shop administrator to approve its Google migration.',
            );
          if (
            db
              .prepare('SELECT 1 FROM google_identities WHERE user_id=?')
              .get(user.id)
          )
            fail(
              409,
              'This email is already linked to a different Google account. Contact the shop.',
            );
          db.prepare('DELETE FROM sessions WHERE user_id=?').run(user.id);
          db.prepare('UPDATE users SET role=? WHERE id=?').run(role, user.id);
          db.prepare('INSERT INTO google_identities VALUES(?,?)').run(
            identity.subject,
            user.id,
          );
          db.prepare(
            'DELETE FROM pending_google_migrations WHERE user_id=?',
          ).run(user.id);
          return { ...userView(user), role };
        }
        user = {
          id: randomUUID(),
          email: identity.email,
          name: identity.name,
          role,
        };
        db.prepare(
          'INSERT INTO users(id,email,name,role,password_hash) VALUES(?,?,?,?,?)',
        ).run(
          user.id,
          user.email,
          user.name,
          user.role,
          passwordHash(randomBytes(64).toString('hex')),
        );
        db.prepare('INSERT INTO google_identities VALUES(?,?)').run(
          identity.subject,
          user.id,
        );
        return user;
      });
    },
    newSession(userId, provider = 'password') {
      db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
      const token = randomBytes(32).toString('hex');
      const csrf = randomBytes(32).toString('hex');
      db.prepare(
        'INSERT INTO sessions(token_hash,user_id,csrf,expires_at,auth_provider) VALUES(?,?,?,?,?)',
      ).run(digest(token), userId, csrf, Date.now() + 7 * 86400_000, provider);
      return { token, csrf };
    },
    session(token) {
      if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
      const row = db
        .prepare(
          'SELECT u.*,s.csrf,s.auth_provider FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?',
        )
        .get(digest(token), Date.now());
      return row
        ? { user: userView(row), csrf: row.csrf, provider: row.auth_provider }
        : null;
    },
    revokeSession(token) {
      if (token)
        db.prepare('DELETE FROM sessions WHERE token_hash=?').run(
          digest(token),
        );
    },
    catalog(owner = false) {
      return db
        .prepare(
          `SELECT * FROM products ${owner ? '' : 'WHERE active=1'} ORDER BY id`,
        )
        .all()
        .map(productView);
    },
    saveProduct(id, body) {
      const p = validateProduct(body);
      if (id == null) {
        const r = db
          .prepare(
            'INSERT INTO products(details,price,stock,active) VALUES(?,?,?,?)',
          )
          .run(JSON.stringify(p), p.price, p.stock, Number(p.active));
        return productView(
          db
            .prepare('SELECT * FROM products WHERE id=?')
            .get(r.lastInsertRowid),
        );
      }
      integer(body.version, 1, Number.MAX_SAFE_INTEGER, 'Product version');
      const r = db
        .prepare(
          'UPDATE products SET details=?,price=?,stock=?,active=?,version=version+1 WHERE id=? AND version=?',
        )
        .run(
          JSON.stringify(p),
          p.price,
          p.stock,
          Number(p.active),
          id,
          body.version,
        );
      if (r.changes !== 1)
        fail(
          409,
          'This product changed. Refresh the catalog before saving again.',
        );
      return productView(
        db.prepare('SELECT * FROM products WHERE id=?').get(id),
      );
    },
    orders(user) {
      return db
        .prepare(
          `SELECT o.*,u.name AS customer_name,u.email AS customer_email FROM orders o JOIN users u ON u.id=o.customer_id ${user.role === 'owner' ? '' : 'WHERE o.customer_id=?'} ORDER BY o.created_at DESC LIMIT 200`,
        )
        .all(...(user.role === 'owner' ? [] : [user.id]))
        .map(orderView);
    },
    placeOrder(user, body, key) {
      if (user.role !== 'customer')
        fail(403, 'Sign in with a customer account to order.');
      text(key, 8, 80, 'Order submission key');
      const delivery = validateDelivery(body.delivery);
      if (!payments.includes(body.payment))
        fail(400, 'Choose a valid payment preference.');
      if (
        !Array.isArray(body.items) ||
        body.items.length < 1 ||
        body.items.length > 30
      )
        fail(400, 'Choose 1–30 products.');
      const seen = new Set();
      const lines = body.items
        .map((line) => {
          const id = integer(line.id, 1, 1_000_000_000, 'Product ID');
          if (seen.has(id)) fail(400, 'Duplicate product in order.');
          seen.add(id);
          return {
            id,
            quantity: integer(line.quantity, 1, 100, 'Quantity'),
            price: integer(line.price, 1, 1_000_000_000_000, 'Reviewed price'),
          };
        })
        .sort((a, b) => a.id - b.id);
      integer(body.expectedTotal, 1, Number.MAX_SAFE_INTEGER, 'Reviewed total');
      const hash = digest(
        JSON.stringify({
          lines,
          delivery,
          payment: body.payment,
          total: body.expectedTotal,
        }),
      );
      return transaction(() => {
        const previous = db
          .prepare(
            'SELECT * FROM orders WHERE customer_id=? AND idempotency_key=?',
          )
          .get(user.id, key);
        if (previous) {
          if (previous.request_hash !== hash)
            fail(409, 'This submission key belongs to another order.');
          return orderView(previous);
        }
        const items = lines.map((line) => {
          const row = db
            .prepare('SELECT * FROM products WHERE id=? AND active=1')
            .get(line.id);
          if (!row || row.stock < line.quantity)
            fail(
              409,
              'Availability changed. Refresh your bag before ordering.',
            );
          if (row.price !== line.price)
            fail(
              409,
              'A price changed. Refresh your bag and review the new total.',
            );
          return {
            id: line.id,
            quantity: line.quantity,
            price: row.price,
            name: JSON.parse(row.details).name,
          };
        });
        const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
        if (total !== body.expectedTotal)
          fail(409, 'The total changed. Review your bag again.');
        for (const item of items)
          db.prepare(
            'UPDATE products SET stock=stock-?,version=version+1 WHERE id=?',
          ).run(item.quantity, item.id);
        const id = `SPL-${randomUUID().toUpperCase()}`;
        const now = new Date().toISOString();
        db.prepare(
          'INSERT INTO orders(id,customer_id,items,delivery,payment,total,created_at,updated_at,idempotency_key,request_hash) VALUES(?,?,?,?,?,?,?,?,?,?)',
        ).run(
          id,
          user.id,
          JSON.stringify(items),
          JSON.stringify(delivery),
          body.payment,
          total,
          now,
          now,
          key,
          hash,
        );
        db.prepare(
          'INSERT INTO order_events(order_id,actor_id,status,created_at) VALUES(?,?,?,?)',
        ).run(id, user.id, 'pending', now);
        return orderView(db.prepare('SELECT * FROM orders WHERE id=?').get(id));
      });
    },
    changeStatus(owner, id, body) {
      if (owner.role !== 'owner') fail(403, 'Owner access required.');
      integer(body.version, 1, Number.MAX_SAFE_INTEGER, 'Order version');
      return transaction(() => {
        const order = db.prepare('SELECT * FROM orders WHERE id=?').get(id);
        if (!order) fail(404, 'Order not found.');
        if (order.version !== body.version)
          fail(409, 'This order changed. Refresh before updating it.');
        if (!nextStatuses[order.status].includes(body.status))
          fail(400, 'That status change is not allowed.');
        if (body.status === 'cancelled') {
          for (const item of JSON.parse(order.items))
            db.prepare(
              'UPDATE products SET stock=stock+?,version=version+1 WHERE id=?',
            ).run(item.quantity, item.id);
        }
        const now = new Date().toISOString();
        db.prepare(
          'UPDATE orders SET status=?,updated_at=?,version=version+1 WHERE id=?',
        ).run(body.status, now, id);
        db.prepare(
          'INSERT INTO order_events(order_id,actor_id,status,created_at) VALUES(?,?,?,?)',
        ).run(id, owner.id, body.status, now);
        return orderView(db.prepare('SELECT * FROM orders WHERE id=?').get(id));
      });
    },
  };
}

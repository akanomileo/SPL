'use client';

import {
  Heart,
  ArrowUpRight,
  Plus,
  Check,
  Laptop,
  Package,
} from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { Product } from '@/lib/catalog';
import { asset, money } from '@/lib/storefront';

export function ProductImage({
  product,
  priority = false,
  className = '',
}: {
  product: Product;
  priority?: boolean;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);
  return failed ? (
    <span className={`image-fallback ${className}`}>
      <Laptop aria-hidden="true" />
      <span>Photo unavailable</span>
    </span>
  ) : (
    // Product images are bundled static assets, with fixed containers to prevent layout shift.
    // oxlint-disable-next-line next/no-img-element -- Local static images need no server optimizer.
    <img
      src={asset(product.image)}
      alt={product.name}
      loading={priority ? 'eager' : 'lazy'}
      decoding="async"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}

export function ProductCard({
  product,
  saved,
  quantity,
  onSave,
  onSelect,
  onAdd,
}: {
  product: Product;
  saved: boolean;
  quantity: number;
  onSave: () => void;
  onSelect: () => void;
  onAdd: () => void;
}) {
  const full = quantity >= product.stock;
  return (
    <article className="product-card">
      <div className="product-visual">
        <span className="product-category">{product.category}</span>
        <button
          className={`save-button ${saved ? 'is-saved' : ''}`}
          aria-label={`${saved ? 'Unsave' : 'Save'} ${product.name}`}
          aria-pressed={saved}
          onClick={onSave}
        >
          <Heart size={18} fill={saved ? 'currentColor' : 'none'} />
        </button>
        <button
          className="product-image-button"
          onClick={onSelect}
          aria-label={`View ${product.name}`}
        >
          <ProductImage product={product} />
        </button>
        <button className="quick-view" onClick={onSelect}>
          View details <ArrowUpRight size={14} />
        </button>
      </div>
      <div className="product-copy">
        <p className="condition">{product.condition}</p>
        <button className="product-title-button" onClick={onSelect}>
          <h3>{product.name}</h3>
        </button>
        <p className="product-subtitle">{product.subtitle}</p>
        <div className="product-bottom">
          <div>
            <p className="price">{money(product.price)}</p>
            {product.oldPrice && (
              <del className="old-price">{money(product.oldPrice)}</del>
            )}
          </div>
          <Button
            onClick={onAdd}
            disabled={full || product.stock <= 0}
            className="add-button"
            aria-label={
              full
                ? `Stock limit reached for ${product.name}`
                : `Add ${product.name} to bag`
            }
          >
            {full ? <Check size={19} /> : <Plus size={19} />}
          </Button>
        </div>
        <p className="stock-line">
          <Package size={12} />{' '}
          {product.stock > 0
            ? `${product.stock} listed in stock`
            : 'Currently unavailable'}
          {quantity > 0 && <span>{quantity} in your bag</span>}
        </p>
      </div>
    </article>
  );
}

export function ProductDetails({
  product,
  quantity,
  saved,
  onClose,
  onAdd,
  onSave,
}: {
  product: Product | null;
  quantity: number;
  saved: boolean;
  onClose: () => void;
  onAdd: () => void;
  onSave: () => void;
}) {
  return (
    <Dialog open={Boolean(product)} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="product-dialog sm:max-w-4xl">
        {product && (
          <div className="detail-grid">
            <div className="detail-photo">
              <span className="eyebrow">{product.category}</span>
              <ProductImage product={product} priority />
              <span className="detail-photo-note">
                Product photo from the supplied catalog
              </span>
            </div>
            <div className="detail-copy">
              <p className="condition">{product.condition}</p>
              <DialogTitle className="detail-title">{product.name}</DialogTitle>
              <DialogDescription className="detail-description">
                {product.subtitle}
              </DialogDescription>
              <div className="detail-price">
                <strong>{money(product.price)}</strong>
                {product.oldPrice && <del>{money(product.oldPrice)}</del>}
              </div>
              <h3 className="small-heading">A closer look</h3>
              <ul className="spec-list">
                {product.specs.map((spec) => (
                  <li key={spec}>
                    <Check size={15} />
                    {spec}
                  </li>
                ))}
              </ul>
              <div className="detail-note">
                <Package size={20} />
                <p>
                  <strong>{product.stock} listed in stock</strong>
                  <span>
                    Confirm the device’s condition, availability and warranty
                    with SPL before payment.
                  </span>
                </p>
              </div>
              <div className="detail-actions">
                <Button
                  onClick={onAdd}
                  disabled={quantity >= product.stock}
                  className="primary-button"
                >
                  {quantity >= product.stock
                    ? 'Stock limit reached'
                    : 'Add to bag'}{' '}
                  <Plus size={17} />
                </Button>
                <Button
                  variant="outline"
                  onClick={onSave}
                  aria-pressed={saved}
                  aria-label={saved ? 'Remove from saved' : 'Save this laptop'}
                  className="outline-button"
                >
                  <Heart size={18} fill={saved ? 'currentColor' : 'none'} />
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

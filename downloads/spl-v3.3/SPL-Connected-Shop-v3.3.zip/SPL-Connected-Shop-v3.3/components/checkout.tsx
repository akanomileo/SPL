'use client';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { AuthForm } from './auth-form';
import type { CartLine } from './shop-cart';
import {
  api,
  errorMessage,
  paymentOptions,
  type ConnectedOrder,
  type Session,
} from '@/lib/connected';
import {
  createRequestId,
  money,
  validateDelivery,
  type Delivery,
} from '@/lib/storefront';

export function Checkout({
  open,
  onOpenChange,
  items,
  onPlaced,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  items: CartLine[];
  onPlaced: () => void;
}) {
  const [session, setSession] = useState<Session | null>(null);
  const [step, setStep] = useState(1);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [order, setOrder] = useState<ConnectedOrder | null>(null);
  const [delivery, setDelivery] = useState<Delivery>({
    name: '',
    phone: '',
    address: '',
    note: '',
  });
  const [payment, setPayment] = useState(paymentOptions[0]);
  const key = useRef<string | null>(null);
  const inFlight = useRef(false);
  useEffect(() => {
    let active = true;
    const refresh = () =>
      api<Session>('/api/auth/session')
        .then((s) => {
          if (active) setSession(s);
        })
        .catch((e) => {
          if (active) setError(errorMessage(e));
        });
    void refresh();
    window.addEventListener('focus', refresh);
    window.addEventListener('spl-session-changed', refresh);
    return () => {
      active = false;
      window.removeEventListener('focus', refresh);
      window.removeEventListener('spl-session-changed', refresh);
    };
  }, []);
  const total = items.reduce(
    (sum, line) => sum + line.product.price * line.quantity,
    0,
  );
  const fields: [keyof Delivery, string, string][] = [
    ['name', 'Full name', 'name'],
    ['phone', 'Phone number', 'tel'],
    ['address', 'Delivery address', 'street-address'],
    ['note', 'Notes (optional)', 'off'],
  ];
  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!busy) onOpenChange(v);
      }}
    >
      <DialogContent className="connected-checkout sm:max-w-2xl">
        <DialogTitle className="panel-title">
          {order
            ? 'Your order was sent.'
            : step === 2
              ? 'Review your order'
              : 'Place your order'}
        </DialogTitle>
        <DialogDescription>
          {order
            ? 'SPL has received it. The shop will confirm availability, delivery and payment with you.'
            : 'Your order goes directly to SPL. No payment is collected on this website.'}
        </DialogDescription>
        {!session && <p>Connecting… {error}</p>}
        {session && !session.user && (
          <AuthForm
            returnTo="/?checkout=1"
            onSignedIn={(s) => {
              setSession(s);
              setError('');
            }}
          />
        )}
        {session?.user?.role === 'owner' && (
          <div>
            <p>
              You are signed in as an owner. Use a customer account to place an
              order.
            </p>
            <button
              className="portal-primary"
              onClick={async () => {
                try {
                  await api('/api/auth/logout', {
                    method: 'POST',
                    csrf: session.csrf,
                  });
                  setSession({ user: null, csrf: null });
                } catch (e) {
                  setError(errorMessage(e));
                }
              }}
            >
              Sign out
            </button>
          </div>
        )}
        {session?.user?.role === 'customer' && !order && step === 1 && (
          <form
            className="portal-form"
            onSubmit={(e) => {
              e.preventDefault();
              const errors = validateDelivery(delivery);
              if (Object.keys(errors).length) {
                setError(Object.values(errors).join(' '));
                return;
              }
              key.current = null;
              setError('');
              setStep(2);
            }}
          >
            <p>Signed in as {session.user.name}</p>
            {fields.map(([name, label, auto]) => (
              <label key={name}>
                {label}
                <input
                  type={name === 'phone' ? 'tel' : 'text'}
                  autoComplete={auto}
                  value={delivery[name]}
                  onChange={(e) =>
                    setDelivery((previous) => ({
                      ...previous,
                      [name]: e.target.value,
                    }))
                  }
                  required={name !== 'note'}
                  maxLength={name === 'address' || name === 'note' ? 300 : 80}
                />
              </label>
            ))}
            <label>
              Payment preference
              <select
                value={payment}
                onChange={(e) => setPayment(e.target.value)}
              >
                {paymentOptions.map((value) => (
                  <option key={value}>{value}</option>
                ))}
              </select>
            </label>
            <p className="portal-muted">
              Your delivery details are sent securely to SPL when you place the
              order. See the privacy information before continuing.
            </p>
            {error && (
              <p role="alert" className="portal-error">
                {error}
              </p>
            )}
            <button className="portal-primary" disabled={!items.length}>
              Review order
            </button>
          </form>
        )}
        {session?.user?.role === 'customer' && !order && step === 2 && (
          <div className="portal-form">
            <ul className="portal-items">
              {items.map(({ product, quantity }) => (
                <li key={product.id}>
                  <span>
                    {quantity} × {product.name}
                  </span>
                  <strong>{money(product.price * quantity)}</strong>
                </li>
              ))}
            </ul>
            <strong className="portal-total">
              Items total: {money(total)}
            </strong>
            <p>Delivery fee: SPL will confirm.</p>
            <p>
              {delivery.name}
              <br />
              {delivery.phone}
              <br />
              {delivery.address}
            </p>
            <p>Preference: {payment}</p>
            <p>
              Stock is reserved when your order reaches SPL. This is an unpaid
              order awaiting confirmation.
            </p>
            {error && (
              <p role="alert" className="portal-error">
                {error}
              </p>
            )}
            <div className="portal-actions">
              <button
                className="portal-secondary"
                disabled={busy}
                onClick={() => {
                  setStep(1);
                  setError('');
                }}
              >
                Back
              </button>
              <button
                className="portal-primary"
                disabled={busy || !items.length}
                onClick={async () => {
                  if (inFlight.current) return;
                  inFlight.current = true;
                  setBusy(true);
                  setError('');
                  try {
                    key.current ??= createRequestId();
                    const result = await api<{ order: ConnectedOrder }>(
                      '/api/orders',
                      {
                        method: 'POST',
                        csrf: session.csrf,
                        key: key.current,
                        body: {
                          items: items.map(({ product, quantity }) => ({
                            id: product.id,
                            quantity,
                            price: product.price,
                          })),
                          delivery,
                          payment,
                          expectedTotal: total,
                        },
                      },
                    );
                    setOrder(result.order);
                    onPlaced();
                  } catch (e) {
                    setError(errorMessage(e));
                  } finally {
                    inFlight.current = false;
                    setBusy(false);
                  }
                }}
              >
                {busy ? 'Sending…' : 'Place order'}
              </button>
            </div>
          </div>
        )}
        {order && (
          <div className="portal-form">
            <output className="portal-success">
              Order received · Pending confirmation
            </output>
            <strong className="order-reference">{order.id}</strong>
            <p>{money(order.total)} items total · Payment not collected</p>
            <p>
              Your bag has been cleared because these items are now in your
              order.
            </p>
            <Link className="portal-primary" href="/account/">
              View my orders
            </Link>
            <button
              className="portal-secondary"
              onClick={() => onOpenChange(false)}
            >
              Continue shopping
            </button>
          </div>
        )}
        {session?.user?.role === 'owner' && error && (
          <p role="alert" className="portal-error">
            {error}
          </p>
        )}
      </DialogContent>
    </Dialog>
  );
}

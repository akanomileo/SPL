'use client';
import Link from 'next/link';

import { useEffect, useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  Heart,
  Laptop,
  MapPin,
  Phone,
  ReceiptText,
  Search,
  ShoppingBag,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { products as seedProducts, type Product } from '@/lib/catalog';
import { api, errorMessage } from '@/lib/connected';
import {
  STORAGE_KEY,
  asset,
  money,
  restoreState,
  searchProducts,
  setQuantity,
  shop,
  sanitizeCart,
  type SortOrder,
} from '@/lib/storefront';
import {
  ProductCard,
  ProductDetails,
  ProductImage,
} from '@/components/shop-product';
import { CartPanel } from '@/components/shop-cart';
import { Checkout } from '@/components/checkout';

type InfoPage = 'how' | 'delivery' | 'privacy' | 'buying' | 'contact';
const infoPages: Record<
  InfoPage,
  {
    title: string;
    intro: string;
    paragraphs: { title: string; text: string }[];
  }
> = {
  how: {
    title: 'A simpler way to order.',
    intro: 'Choose online. Confirm with a person at SPL.',
    paragraphs: [
      {
        title: '01 · Find your laptop',
        text: 'Browse the catalog, compare the specifications and add your selection to your bag. Listed stock is a guide; the shop confirms availability.',
      },
      {
        title: '02 · Place your order',
        text: 'Create a customer account, enter delivery details and review your selection. Place the order to send it directly to SPL. No payment is taken on this website.',
      },
      {
        title: '03 · Track confirmation',
        text: `The shop receives your order in its dashboard. Track status in My orders or call ${shop.phone}. SPL will confirm condition, warranty, delivery and payment before you pay.`,
      },
    ],
  },
  delivery: {
    title: 'Delivery, returns & warranty',
    intro: 'Confirm the details for your specific device before purchase.',
    paragraphs: [
      {
        title: 'Delivery',
        text: 'Contact SPL with your township and city for delivery options, cost and estimated timing. Delivery is not included in the item subtotal displayed here.',
      },
      {
        title: 'Returns and warranty',
        text: 'Warranty and return terms may depend on the device. Ask the shop for the applicable terms and what is covered before confirming your purchase.',
      },
      {
        title: 'Payment',
        text: 'Payment choices in the order are preferences. SPL must confirm the available method and payment instructions directly. This website does not collect payment details or transfer money.',
      },
    ],
  },
  privacy: {
    title: 'Your privacy, kept simple.',
    intro: 'Browse freely. Create an account to place and track orders.',
    paragraphs: [
      {
        title: 'Saved on this device',
        text: 'Your bag and saved products are kept in this browser. Orders are stored securely on the shop server and are available when you sign in on another device. Old local request history can be removed by clearing site data.',
      },
      {
        title: 'Your delivery details',
        text: 'When you place an order, your name, phone, address and notes are sent to the shop server so SPL can arrange delivery. They are visible to you and authorized shop owners, and are not stored in your browser’s local storage. Contact SPL about correcting or removing your information.',
      },
      {
        title: 'When you share',
        text: 'Sign out when using a shared device. Payment preferences are included in your order; this website does not collect card numbers, banking credentials or payment transfers.',
      },
    ],
  },
  buying: {
    title: 'Find the right fit.',
    intro: 'A few practical questions make choosing easier.',
    paragraphs: [
      {
        title: 'For everyday work',
        text: 'Compare the processor, memory and storage against the apps you use. Business laptops are a useful place to start for documents, browsing and study.',
      },
      {
        title: 'For creative projects',
        text: 'Check the exact graphics model, memory and display specifications against your software’s requirements. Workstations offer a starting point; the model details matter.',
      },
      {
        title: 'For life on the move',
        text: 'Compare screen size, weight and battery condition. Explore Ultrabook and 2-in-1 categories for portability or a flexible touchscreen.',
      },
      {
        title: 'Before you buy',
        text: 'Ask SPL for current photos, battery health, the included charger, physical condition and warranty terms for the actual unit.',
      },
    ],
  },
  contact: {
    title: 'Talk to SHWE PYAE SAN.',
    intro: 'Get help choosing a laptop or confirming an order.',
    paragraphs: [
      { title: 'Call the shop', text: `${shop.phone} · ${shop.city}` },
      {
        title: 'Already placed an order?',
        text: 'Sign in to My orders to see the current status. Call SPL with your order reference if you need help.',
      },
    ],
  },
};

function BrandMark() {
  return (
    <span
      className="brand-mark"
      aria-hidden="true"
      style={{ backgroundImage: `url('${asset('/spl-original-logo.png')}')` }}
    />
  );
}

export default function Storefront({
  onSignOut,
  sessionError,
}: {
  onSignOut: () => Promise<void>;
  sessionError: string;
}) {
  const [products, setProducts] = useState<Product[]>(seedProducts);
  const [catalogReady, setCatalogReady] = useState(false);
  const [catalogError, setCatalogError] = useState('');
  const [catalogEpoch, setCatalogEpoch] = useState(0);
  const categories = [
    'All laptops',
    ...new Set(products.map((p) => p.category)),
  ];
  const [state, setState] = useState(() => restoreState(null, seedProducts));
  const [ready, setReady] = useState(false);
  const [storageProblem, setStorageProblem] = useState(false);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All laptops');
  const [sort, setSort] = useState<SortOrder>('featured');
  const [savedOnly, setSavedOnly] = useState(false);
  const [selected, setSelected] = useState<Product | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [requestOpen, setRequestOpen] = useState(false);
  const [requestRun, setRequestRun] = useState(0);
  const [info, setInfo] = useState<InfoPage | null>(null);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    try {
      // oxlint-disable-next-line react/react-compiler -- Restore browser storage after hydration so initial HTML is stable.
      setState(restoreState(localStorage.getItem(STORAGE_KEY), seedProducts));
    } catch {
      setStorageProblem(true);
    }
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready || !catalogReady) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // oxlint-disable-next-line react/react-compiler -- Report an unavailable external storage system to the customer.
      setStorageProblem(true);
    }
  }, [ready, state, catalogReady]);
  useEffect(() => {
    if (notice) {
      const timeout = window.setTimeout(() => setNotice(''), 3500);
      return () => window.clearTimeout(timeout);
    }
  }, [notice]);

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const result = await api<{ products: Product[] }>('/api/catalog');
        if (!active) return;
        setProducts(result.products);
        setState((previous) => ({
          ...previous,
          cart: sanitizeCart(previous.cart, result.products),
        }));
        setSelected((previous) =>
          previous
            ? (result.products.find((p) => p.id === previous.id) ?? null)
            : null,
        );
        setCatalogReady(true);
        setCatalogError('');
      } catch (error) {
        if (active) {
          setCatalogError(errorMessage(error));
          setCatalogReady(false);
        }
      }
    };
    void load();
    const interval = setInterval(() => void load(), 15000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [catalogEpoch]);

  const filtered = useMemo(
    () =>
      searchProducts(products, query, category, sort).filter(
        (product) => !savedOnly || state.saved.includes(product.id),
      ),
    [query, category, sort, savedOnly, state.saved, products],
  );
  const items = products
    .filter((product) => state.cart[product.id])
    .map((product) => ({ product, quantity: state.cart[product.id] }));
  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  const jumpToCatalog = (saved = false) => {
    setSavedOnly(saved);
    setQuery('');
    setCategory('All laptops');
    document.getElementById('catalog')?.scrollIntoView({
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches
        ? 'instant'
        : 'smooth',
    });
  };
  const toggleSave = (product: Product) => {
    setState((previous) => ({
      ...previous,
      saved: previous.saved.includes(product.id)
        ? previous.saved.filter((id) => id !== product.id)
        : [...previous.saved, product.id],
    }));
  };
  const add = (product: Product) => {
    if (!ready || !catalogReady) return;
    if ((state.cart[product.id] ?? 0) >= product.stock) {
      setNotice('All listed units of this laptop are already in your bag.');
      return;
    }
    setState((previous) => ({
      ...previous,
      cart: setQuantity(
        previous.cart,
        product,
        (previous.cart[product.id] ?? 0) + 1,
      ),
    }));
    setNotice(`${product.name} added to your bag.`);
  };
  const startRequest = () => {
    setCartOpen(false);
    setRequestRun((previous) => previous + 1);
    setRequestOpen(true);
  };
  const orderPlaced = () => {
    setState((previous) => ({ ...previous, cart: {} }));
    setCatalogEpoch((previous) => previous + 1);
    setNotice('Order sent to SPL. See your account for its latest status.');
  };

  return (
    <>
      <a className="skip-link" href="#catalog">
        Skip to laptops
      </a>
      <div className="announcement">
        <div className="site-width">
          <span>
            <MapPin size={13} /> {shop.city}
          </span>
          <span>Find your laptop. Talk to your local shop.</span>
          <a href={shop.phoneHref}>
            <Phone size={13} />
            {shop.phone}
          </a>
        </div>
      </div>
      {(!catalogReady || catalogError) && (
        <output className="catalog-connection">
          {catalogError
            ? 'The shop connection is unavailable. Ordering is paused until it reconnects.'
            : 'Connecting to the live shop catalog…'}
          <button onClick={() => setCatalogEpoch((previous) => previous + 1)}>
            Retry connection
          </button>
        </output>
      )}
      <header className="site-header">
        <div className="site-width header-inner">
          <a
            className="brand"
            href="#top"
            aria-label="SHWE PYAE SAN home"
            onClick={() => {
              setSavedOnly(false);
              setQuery('');
              setCategory('All laptops');
            }}
          >
            <BrandMark />
            <span>
              <strong>SHWE PYAE SAN</strong>
              <small>LAPTOP & MOBILE</small>
            </span>
          </a>
          <nav className="desktop-nav" aria-label="Main navigation">
            <button
              className={!savedOnly ? 'active' : ''}
              onClick={() => jumpToCatalog()}
            >
              Laptops
            </button>
            <button
              className={savedOnly ? 'active' : ''}
              onClick={() => jumpToCatalog(true)}
            >
              Saved{' '}
              {state.saved.length > 0 && <span>{state.saved.length}</span>}
            </button>
            <button onClick={() => setInfo('how')}>How to order</button>
          </nav>
          <div className="header-actions">
            <button className="shop-signout" onClick={() => void onSignOut()}>
              Sign out
            </button>
            <Link
              className="header-request"
              href="/account/"
              aria-label="My orders"
            >
              <ReceiptText size={20} />
              <span>My orders</span>
            </Link>
            <Button
              className="bag-button"
              onClick={() => setCartOpen(true)}
              aria-label={`Shopping bag, ${count} items`}
            >
              <ShoppingBag size={18} />
              <span className="bag-word">Bag</span>
              <span className="bag-count">{count}</span>
            </Button>
          </div>
        </div>
      </header>
      <main id="top" className="site-width">
        {sessionError && (
          <p role="alert" className="portal-error">
            {sessionError}
          </p>
        )}
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-copy">
            <div className="hero-kicker">
              <span /> BUILT FOR YOUR EVERYDAY
            </div>
            <h1 id="hero-title">
              Good laptops.
              <br />
              <span>Better beginnings.</span>
            </h1>
            <p>
              For the work you do. The things you create. And whatever comes
              next. Find your next laptop at SHWE PYAE SAN.
            </p>
            <div className="hero-actions">
              <Button
                className="primary-button"
                onClick={() => jumpToCatalog()}
              >
                Explore the collection <ArrowDown size={16} />
              </Button>
              <button className="text-button" onClick={() => setInfo('buying')}>
                Find your fit <ArrowUpRight size={17} />
              </button>
            </div>
            <div className="hero-meta">
              <span>Business classics</span>
              <i />
              <span>Creative workstations</span>
              <i />
              <span>Everyday essentials</span>
            </div>
          </div>
          {products[0] ? (
            <button
              className="hero-product"
              onClick={() => setSelected(products[0])}
              aria-label={`View ${products[0].name}`}
            >
              <div className="hero-product-top">
                <span>THE BUSINESS EDIT</span>
                <span>01 / {String(products.length).padStart(2, '0')}</span>
              </div>
              <div className="hero-image">
                <ProductImage product={products[0]} priority />
              </div>
              <div className="hero-product-bottom">
                <div>
                  <span>{products[0].name}</span>
                  <strong>{money(products[0].price)}</strong>
                </div>
                <span className="hero-circle">
                  <ArrowUpRight size={22} />
                </span>
              </div>
            </button>
          ) : (
            <div className="hero-product">
              <p>
                New products are coming soon. Contact SPL for current
                availability.
              </p>
            </div>
          )}
        </section>
        <div className="service-strip">
          <div>
            <Laptop />
            <p>
              <strong>Know what you’re buying</strong>
              <span>Clear specs and listed condition</span>
            </p>
          </div>
          <div>
            <Phone />
            <p>
              <strong>A real person to help</strong>
              <span>Arrange your purchase with SPL</span>
            </p>
          </div>
          <div>
            <ReceiptText />
            <p>
              <strong>Your order, your account</strong>
              <span>Place orders and track confirmation</span>
            </p>
          </div>
        </div>
        <section
          id="catalog"
          className="catalog"
          aria-labelledby="catalog-title"
        >
          <div className="section-heading">
            <div>
              <span className="eyebrow">
                {savedOnly ? 'YOUR SHORTLIST' : 'THE COLLECTION'}
              </span>
              <h2 id="catalog-title">
                {savedOnly
                  ? 'A few good possibilities.'
                  : 'Find your everyday upgrade.'}
              </h2>
            </div>
            <output className="product-count">
              {filtered.length} {filtered.length === 1 ? 'laptop' : 'laptops'}
            </output>
          </div>
          <div className="catalog-toolbar">
            <div className="category-tabs" aria-label="Laptop category">
              {categories.map((value) => (
                <button
                  key={value}
                  aria-pressed={category === value}
                  className={category === value ? 'selected' : ''}
                  onClick={() => setCategory(value)}
                >
                  {value}
                  {value === 'All laptops' && (
                    <span>
                      {savedOnly ? state.saved.length : products.length}
                    </span>
                  )}
                </button>
              ))}
            </div>
            <div className="catalog-controls">
              <div className="search-box">
                <Search size={17} />
                <input
                  type="search"
                  aria-label="Search laptops"
                  placeholder="Search model, brand or specs"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
                {query && (
                  <button
                    className="quiet-icon"
                    onClick={() => setQuery('')}
                    aria-label="Clear search"
                  >
                    <X size={15} />
                  </button>
                )}
              </div>
              <div className="sort-box">
                <SlidersHorizontal size={15} />
                <select
                  aria-label="Sort laptops"
                  value={sort}
                  onChange={(event) => setSort(event.target.value as SortOrder)}
                >
                  <option value="featured">Featured</option>
                  <option value="price-asc">Price: low to high</option>
                  <option value="price-desc">Price: high to low</option>
                </select>
              </div>
            </div>
          </div>
          {savedOnly && (
            <div className="saved-banner">
              <Heart size={16} />
              <span>Your favorites, saved on this device.</span>
              <button className="text-button" onClick={() => jumpToCatalog()}>
                See all laptops <ArrowRight size={14} />
              </button>
            </div>
          )}
          {storageProblem && (
            <output className="storage-warning">
              Browser storage is unavailable. Your bag and saved items will last
              for this visit only; your submitted orders remain in your account.
            </output>
          )}
          {filtered.length ? (
            <div className="product-grid">
              {filtered.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  saved={state.saved.includes(product.id)}
                  quantity={state.cart[product.id] ?? 0}
                  onSave={() => toggleSave(product)}
                  onSelect={() => setSelected(product)}
                  onAdd={() => add(product)}
                />
              ))}
            </div>
          ) : (
            <div className="catalog-empty">
              {savedOnly ? (
                <Heart size={38} strokeWidth={1.3} />
              ) : (
                <Search size={38} strokeWidth={1.3} />
              )}
              <h3>
                {savedOnly && !state.saved.length
                  ? 'Make room for your favorites.'
                  : 'No laptops match just yet.'}
              </h3>
              <p>
                {savedOnly && !state.saved.length
                  ? 'Tap the heart on a laptop to keep it in your shortlist.'
                  : 'Try another model, a shorter search or a different category.'}
              </p>
              <Button
                variant="outline"
                className="outline-button"
                onClick={() => {
                  if (!state.saved.length) setSavedOnly(false);
                  setQuery('');
                  setCategory('All laptops');
                }}
              >
                Show {savedOnly && state.saved.length ? 'saved' : 'all'} laptops{' '}
                <ArrowRight size={16} />
              </Button>
            </div>
          )}
          <p className="catalog-disclaimer">
            Prices and specifications are from the shop’s catalog. Confirm
            current stock, condition and final pricing with SPL.
          </p>
        </section>
        <section className="help-banner">
          <div>
            <span className="eyebrow">A LITTLE GUIDANCE GOES A LONG WAY</span>
            <h2>Not sure which one feels right?</h2>
            <p>Tell us what you need it for. We’ll help you narrow it down.</p>
          </div>
          <a className="button-link light-button" href={shop.phoneHref}>
            <Phone size={18} /> Talk to SPL <ArrowUpRight size={17} />
          </a>
        </section>
      </main>
      <footer className="site-footer">
        <div className="site-width footer-grid">
          <div>
            <a className="brand footer-brand" href="#top">
              <BrandMark />
              <span>
                <strong>SHWE PYAE SAN</strong>
                <small>LAPTOP & MOBILE</small>
              </span>
            </a>
            <p>
              Your next laptop, with a local connection.
              <br />
              {shop.city}
            </p>
            <a className="footer-phone" href={shop.phoneHref}>
              {shop.phone} <ArrowUpRight size={15} />
            </a>
          </div>
          <div>
            <h3>Explore</h3>
            <button onClick={() => jumpToCatalog()}>All laptops</button>
            <button onClick={() => jumpToCatalog(true)}>Saved products</button>
            <button onClick={() => setInfo('buying')}>
              Choosing your laptop
            </button>
          </div>
          <div>
            <h3>Here to help</h3>
            <button onClick={() => setInfo('how')}>How to order</button>
            <button onClick={() => setInfo('delivery')}>
              Delivery & warranty
            </button>
            <button onClick={() => setInfo('contact')}>Contact the shop</button>
          </div>
          <div>
            <h3>Your visit</h3>
            <button onClick={() => window.location.assign('/account/')}>
              My orders
            </button>
            <button onClick={() => setInfo('privacy')}>
              Privacy & local storage
            </button>
            <p className="footer-note">
              No sign-in needed.
              <br />
              Orders go directly to SPL. No payment taken online.
            </p>
          </div>
        </div>
        <div className="site-width footer-bottom">
          <span>© SHWE PYAE SAN Laptop & Mobile</span>
          <span>Choose thoughtfully. Upgrade confidently.</span>
        </div>
      </footer>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        <button
          aria-current={!savedOnly ? 'page' : undefined}
          className={!savedOnly ? 'active' : ''}
          onClick={() => jumpToCatalog()}
        >
          <Laptop size={20} />
          <span>Shop</span>
        </button>
        <button
          className={savedOnly ? 'active' : ''}
          onClick={() => jumpToCatalog(true)}
        >
          <Heart size={20} />
          <span>
            Saved{state.saved.length > 0 ? ` (${state.saved.length})` : ''}
          </span>
        </button>
        <button onClick={() => setCartOpen(true)}>
          <ShoppingBag size={20} />
          <span>Bag{count ? ` (${count})` : ''}</span>
        </button>
        <Link href="/account/" aria-label="My orders">
          <ReceiptText size={20} />
          <span>Orders</span>
        </Link>
      </nav>
      {notice && (
        <output className="shop-toast">
          <Check size={18} />
          <span>{notice}</span>
          <button
            aria-label="Dismiss notification"
            onClick={() => setNotice('')}
          >
            <X size={15} />
          </button>
        </output>
      )}
      <ProductDetails
        product={selected}
        quantity={selected ? (state.cart[selected.id] ?? 0) : 0}
        saved={selected ? state.saved.includes(selected.id) : false}
        onClose={() => setSelected(null)}
        onAdd={() => selected && add(selected)}
        onSave={() => selected && toggleSave(selected)}
      />
      <CartPanel
        open={cartOpen}
        onOpenChange={setCartOpen}
        items={items}
        onQuantity={(product, quantity) =>
          setState((previous) => ({
            ...previous,
            cart: setQuantity(previous.cart, product, quantity),
          }))
        }
        onCheckout={() =>
          catalogReady
            ? startRequest()
            : setNotice('Connect to the shop before placing an order.')
        }
      />
      <Checkout
        key={requestRun}
        open={requestOpen}
        onOpenChange={setRequestOpen}
        items={items}
        onPlaced={orderPlaced}
      />
      <Dialog
        open={Boolean(info)}
        onOpenChange={(open) => !open && setInfo(null)}
      >
        <DialogContent className="info-dialog sm:max-w-xl">
          {info && (
            <>
              <span className="eyebrow">SHWE PYAE SAN</span>
              <DialogTitle className="panel-title">
                {infoPages[info].title}
              </DialogTitle>
              <DialogDescription>{infoPages[info].intro}</DialogDescription>
              <div className="info-sections">
                {infoPages[info].paragraphs.map((paragraph) => (
                  <section key={paragraph.title}>
                    <h3>{paragraph.title}</h3>
                    <p>{paragraph.text}</p>
                  </section>
                ))}
              </div>
              {info === 'contact' && (
                <a className="primary-button button-link" href={shop.phoneHref}>
                  <Phone size={17} /> Call {shop.phone}
                </a>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

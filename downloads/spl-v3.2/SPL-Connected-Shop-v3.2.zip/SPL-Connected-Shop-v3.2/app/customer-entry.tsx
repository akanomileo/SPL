'use client';
import { useEffect, useState } from 'react';
import { AuthForm } from '@/components/auth-form';
import { api, errorMessage, type Session } from '@/lib/connected';
import Storefront from './storefront';
export default function CustomerEntry() {
  const [session, setSession] = useState<Session | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    async function refresh() {
      try {
        const value = await api<Session>('/api/auth/session');
        if (!active) return;
        if (value.user?.role === 'owner') {
          window.location.replace('/owner/');
          return;
        }
        setSession(value);
        setError('');
      } catch (e) {
        if (active) {
          setSession(null);
          setError(errorMessage(e));
        }
      }
    }
    void refresh();
    const timer = setInterval(() => void refresh(), 15000);
    window.addEventListener('focus', refresh);
    return () => {
      active = false;
      clearInterval(timer);
      window.removeEventListener('focus', refresh);
    };
  }, []);
  if (!session?.user)
    return (
      <div className="customer-entry">
        <header className="entry-brand">
          SHWE PYAE SAN <small>LAPTOP & MOBILE</small>
        </header>
        <main className="entry-main">
          <div className="entry-intro">
            <span className="eyebrow">YOUR NEXT LAPTOP STARTS HERE</span>
            <h1>Welcome to SPL.</h1>
            <p>
              Sign in with Google to browse the collection, place an order and
              keep track of it.
            </p>
          </div>
          <AuthForm />
          {error && (
            <p role="alert" className="portal-error">
              {error}
            </p>
          )}
        </main>
        <footer className="entry-footer">
          A good laptop. A better beginning.
        </footer>
      </div>
    );
  return (
    <Storefront
      onSignOut={async () => {
        try {
          await api('/api/auth/logout', { method: 'POST', csrf: session.csrf });
          setSession(null);
          setError('');
        } catch (e) {
          setError(errorMessage(e));
        }
      }}
      sessionError={error}
    />
  );
}

'use client';
import { GoogleAccount } from './google-account';
import type { Session } from '@/lib/connected';
export function AuthForm({
  owner = false,
}: {
  owner?: boolean;
  onSignedIn?: (session: Session) => void;
}) {
  return (
    <section className="auth-card google-only-card">
      <span className="eyebrow">
        {owner ? 'OWNER ACCOUNT' : 'WELCOME TO SPL'}
      </span>
      <h2>
        {owner ? 'Sign in to your shop' : 'Sign in or create your account'}
      </h2>
      <p>
        {owner
          ? 'Use your configured Google owner account to manage products and orders.'
          : 'Continue with Google to enter the shop and track your orders.'}
      </p>
      <GoogleAccount owner={owner} />
      <p className="auth-footnote">
        Your first Google sign-in creates your account automatically. Use the
        same account to sign in next time.
      </p>
    </section>
  );
}

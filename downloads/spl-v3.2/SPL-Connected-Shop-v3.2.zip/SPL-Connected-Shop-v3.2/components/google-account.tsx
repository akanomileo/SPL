'use client';
import { useEffect, useState } from 'react';
import { api, errorMessage } from '@/lib/connected';
type Config = {
  enabled: boolean;
  ownerEnabled: boolean;
  ownerSetupRequired: boolean;
};
export function GoogleAccount({ owner = false }: { owner?: boolean }) {
  const [config, setConfig] = useState<Config | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [setupCode, setSetupCode] = useState('');
  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const value = await api<Config>('/api/auth/google/config');
        if (!active) return;
        setConfig(value);
        const message = new URLSearchParams(window.location.search).get(
          'authError',
        );
        if (message) {
          setError(message.slice(0, 500));
          const clean = new URL(window.location.href);
          clean.searchParams.delete('authError');
          window.history.replaceState(
            window.history.state,
            '',
            clean.pathname + clean.search + clean.hash,
          );
        }
      } catch (e) {
        if (active) {
          setConfig({
            enabled: false,
            ownerEnabled: false,
            ownerSetupRequired: false,
          });
          setError(errorMessage(e));
        }
      }
    }
    void load();
    return () => {
      active = false;
    };
  }, []);
  const enabled = config?.enabled && (!owner || config.ownerEnabled);
  const setup = owner && config?.ownerSetupRequired && enabled;
  return (
    <div className="google-account">
      {setup ? (
        <form
          onSubmit={async (event) => {
            event.preventDefault();
            if (busy) return;
            setBusy(true);
            setError('');
            try {
              const result = await api<{ url: string }>(
                '/api/auth/google/start',
                { method: 'POST', body: { audience: 'owner', setupCode } },
              );
              setSetupCode('');
              window.location.assign(result.url);
            } catch (e) {
              setError(errorMessage(e));
              setBusy(false);
            }
          }}
        >
          <p>
            Choose the one Google account that will own this shop. Enter your
            private setup code for this first sign-in.
          </p>
          <label>
            Private owner setup code
            <input
              type="password"
              value={setupCode}
              onChange={(event) => setSetupCode(event.target.value)}
              autoComplete="off"
              required
              maxLength={200}
            />
          </label>
          <button className="portal-secondary google-signin" disabled={busy}>
            {busy ? 'Opening Google…' : 'Continue with Google'}
          </button>
        </form>
      ) : enabled ? (
        <a
          className="portal-secondary google-signin"
          href={`/api/auth/google/start?audience=${owner ? 'owner' : 'customer'}`}
        >
          Continue with Google
        </a>
      ) : (
        <>
          <button className="portal-secondary google-signin" disabled>
            {config
              ? 'Google sign-in unavailable'
              : 'Connecting to Google sign-in…'}
          </button>
          {config && (
            <small>
              {owner
                ? 'The shop administrator needs to complete owner sign-in setup.'
                : 'Google sign-in has not been configured by the shop yet.'}
            </small>
          )}
        </>
      )}
      {enabled && !setup && (
        <small>
          {owner
            ? 'Only the configured owner account can enter this dashboard.'
            : 'Use your Gmail or Google Workspace account.'}
        </small>
      )}
      {error && (
        <p role="alert" className="portal-error">
          {error}
        </p>
      )}
    </div>
  );
}

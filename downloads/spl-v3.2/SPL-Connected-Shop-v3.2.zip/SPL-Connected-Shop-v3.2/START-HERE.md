# SPL v3.2 — Google-only customer and single owner

1. Install Node.js 22.13+ and extract the complete ZIP.
2. Follow GOOGLE-SETUP.md to create a Google OAuth client and configure `.env.local`. There are no supplied Google credentials or sample owner account.
3. Open PowerShell in the folder containing package.json:

```powershell
npm.cmd run owner:setup
npm.cmd start
```

Copy the private code printed by owner:setup. Open http://localhost:4174/owner/, enter that code once, and choose the one Google account that will own the shop. No Google password is entered in this app. Future owner login uses Google only.

Customers open http://localhost:4174/ and see the Google login/sign-up page first; successful sign-in opens the shop. Existing Google users sign in; new Google users are registered automatically. Customer orders: http://localhost:4174/account/.

Use a separate browser/private window to test customers. Owner links are absent from customer navigation. No fixed owner email is used; only one configured Google account can access the owner dashboard.

Keep PowerShell open while browsing. Google configuration is required to access the shop; password login is disabled. Read README.md before updating, replacing the owner or hosting. Preserve the existing data folder and .env.local when upgrading.

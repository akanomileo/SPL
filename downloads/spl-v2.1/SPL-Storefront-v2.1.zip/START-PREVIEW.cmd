@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required to run this local preview. See README.md.
  pause
  exit /b 1
)
echo Open the address shown below in your browser.
node "scripts\preview.mjs"
pause

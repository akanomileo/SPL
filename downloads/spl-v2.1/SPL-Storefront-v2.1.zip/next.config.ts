import type { NextConfig } from 'next';

const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? '';

const nextConfig: NextConfig = {
  output: 'export',
  // This is one exported page with in-page navigation. Keep the render route
  // at /; Vinext beta.5 prerenders / without adding Next's basePath. Assets
  // use the hosting prefix below and the shared asset() helper instead.
  assetPrefix: basePath || undefined,
  images: { unoptimized: true },
};

export default nextConfig;

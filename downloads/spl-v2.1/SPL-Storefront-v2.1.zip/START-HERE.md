# SPL Storefront v2.1

To view: install Node.js 22.13+, then double-click START-PREVIEW.cmd on Windows, or run `node scripts/preview.mjs`. Open the address printed in the terminal.

To host: upload the contents of the Ready-to-Upload ZIP or dist/client to your domain root, usually public_html. Enable HTTPS. Source code and node_modules do not belong in that public folder.

The included build is portable and uses no invented domain. Set your real NEXT_PUBLIC_SITE_URL and rebuild from the source project to generate canonical URLs, social metadata and a sitemap. Read README.md for subfolder hosting and product edits.

Customers must copy or download their prepared request and share it with SPL. Preparation does not submit an order or collect payment. The bag remains available. Saved request history contains product lists only; contact details are not stored.

Check actual photos, prices, inventory, specifications, warranty and contact details before launch. Read RELEASE-NOTES.md for validation and remaining limitations. Nothing has been published automatically.

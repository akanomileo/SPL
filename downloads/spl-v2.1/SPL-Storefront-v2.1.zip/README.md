# SHWE PYAE SAN — Storefront v2.1

A static, single-shop laptop storefront. Customers can search eight listings, save products, manage a stock-limited bag and prepare an order request to share with SPL. Requests are not sent automatically; no payments, accounts, inventory reservations or server tracking are connected.

## Preview the included website

Install Node.js 22.13 or newer. On Windows, double-click START-PREVIEW.cmd. On other platforms, run `node scripts/preview.mjs`. Open the address printed in the terminal. No dependency installation is needed for this preview. Serve files over HTTP instead of opening index.html directly.

## Develop and verify

```sh
npm ci
npm run dev
npm run typecheck
npm run lint
npm test
npm run build
npm run preview
```

## Host at your domain

The separate Ready-to-Upload ZIP contains only static hosting files. Extract it and upload its contents to your domain's document root, often public_html. index.html, _next and products must be together at that root. Node.js is not required on the hosting server. Enable HTTPS and redirect HTTP to HTTPS in your hosting settings. The included package is built for a domain root, not a subfolder.

For domain-specific canonical URLs, sharing images and a sitemap, copy .env.example to .env.local and set NEXT_PUBLIC_SITE_URL to your actual full HTTPS URL. Leave NEXT_PUBLIC_BASE_PATH empty for the domain root. Rebuild with `npm run build`, then upload the contents of dist/client. The build refuses example domains and mismatched URL/base paths. A blank URL produces a portable build with no invented canonical URL or sitemap; robots.txt is still included.

For a subfolder, set the full site URL including that path and set NEXT_PUBLIC_BASE_PATH to the same path, for example /shop. Rebuild and upload dist/client into the corresponding hosting folder. GitHub Pages uses the included workflow and Configure Pages outputs. Source belongs at the repository root, and Pages must use GitHub Actions.

## Edit shop details

- lib/catalog.ts: names, prices, stock, condition, specifications and warranty.
- lib/storefront.ts: shop phone and city.
- public/products: actual product photos; ASSET-SOURCES.json records inherited third-party sources.
- app/storefront.tsx: homepage and customer information.
- app/shop.css: appearance.
- app/layout.tsx: metadata.

Verify product/photo matches, image usage rights, specifications, prices, real stock, phone number and warranty before launch. Stock limits are catalog values, not shared live inventory. Product listings were not independently authenticated or altered in this release.

## Requests and privacy

Phone validation accepts both ASCII and Myanmar digits. Prepared summaries normalize Myanmar phone digits to ASCII. Request references use browser cryptographic randomness and have a fallback when randomUUID is unavailable. If no secure random generator exists, the page shows an error and retains the customer's data.

Preparing a request keeps the bag. Copy or download the full summary before leaving. My requests saves only references and product lists; later history downloads omit delivery details. Names, phone numbers, addresses, notes and payment preferences remain in page memory and in customer-initiated copies/downloads. They are not persisted in browser storage or sent to SPL. Reloading loses those details. Requests do not sync between devices.

## Maintenance

React, Vinext, Vite, the RSC plugin and formatter are pinned to updated versions in package.json and package-lock.json. The shadcn CLI dependency was removed; its original MIT Tailwind stylesheet is retained locally with its license in THIRD-PARTY-LICENSES. Generated UI component source remains available.

See RELEASE-NOTES.md for verified results and remaining dependency limitations. Compatibility helpers are retained for static asset normalization and Windows process exit handling; reassess them when upgrading the framework or adding routes.

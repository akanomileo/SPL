# SPL Connected Shop v3.1

Install Node.js 22.13+, extract this complete ZIP, and open a terminal in this folder.

For password sign-in, create your private owner account:

```powershell
npm.cmd run owner:create
```

Start both interfaces and their shared backend:

```powershell
npm.cmd start
```

Customer: http://127.0.0.1:4174/
Owner: http://127.0.0.1:4174/owner/
Customer orders: http://127.0.0.1:4174/account/

You can also double-click START-PREVIEW.cmd after creating the owner. Customers register on the website. Use separate browser/private windows to test both roles.

This package has a real local SQLite database. Preserve data/ between restarts and updates, and keep it private. No sample account/password or test customer data is included.

For development: `npm.cmd ci`, then `npm.cmd run dev`. Customer and owner pages use port 3000; the API uses port 3001.

The application sends orders directly to the owner and reserves available stock. Payments are confirmed separately with the shop. Domain hosting requires a Node.js server and persistent disk, not only a static public_html upload. Read README.md before hosting or collecting real customer data.

For Google sign-in (customers and owners), follow GOOGLE-SETUP.md to create a Google OAuth client and configure .env.local. A fresh approved Google owner account does not need the password owner:create step. Keep your client secret private.

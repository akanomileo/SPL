'use client';
import { useEffect, useState } from 'react';
import { api, errorMessage, type Session } from '@/lib/connected';
type Config = { enabled: boolean; ownerEnabled: boolean };
export function GoogleAccount({
  owner = false,
  session,
}: {
  owner?: boolean;
  session?: Session;
}) {
  const [config, setConfig] = useState<Config | null>(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const value = await api<Config>('/api/auth/google/config');
        if (!active) return;
        setConfig(value);
        const message = new URLSearchParams(window.location.search).get(
          'authError',
        );
        if (message) {
          setError(message.slice(0, 500));
          const clean = new URL(window.location.href);
          clean.searchParams.delete('authError');
          window.history.replaceState(
            window.history.state,
            '',
            clean.pathname + clean.search + clean.hash,
          );
        }
      } catch {
        /* Password sign-in remains available if config cannot load. */
      }
    }
    void load();
    return () => {
      active = false;
    };
  }, []);
  const enabled = config?.enabled && (!owner || config.ownerEnabled);
  return (
    <div className="google-account">
      {enabled &&
        (session?.user ? (
          <button
            className="portal-secondary"
            disabled={busy}
            onClick={async () => {
              if (busy) return;
              setBusy(true);
              setError('');
              try {
                const result = await api<{ url: string }>(
                  '/api/auth/google/link',
                  { method: 'POST', csrf: session.csrf },
                );
                window.location.assign(result.url);
              } catch (e) {
                setError(errorMessage(e));
                setBusy(false);
              }
            }}
          >
            {busy ? 'Opening Google…' : 'Link Google account'}
          </button>
        ) : (
          <a
            className="portal-secondary google-signin"
            href={`/api/auth/google/start?audience=${owner ? 'owner' : 'customer'}`}
          >
            Continue with Google
          </a>
        ))}
      {enabled && !session?.user && (
        <small>
          {owner
            ? 'Use the Google account approved by the shop administrator.'
            : 'Use your Gmail or Google Workspace account.'}
        </small>
      )}
      {error && (
        <p role="alert" className="portal-error">
          {error}
        </p>
      )}
    </div>
  );
}

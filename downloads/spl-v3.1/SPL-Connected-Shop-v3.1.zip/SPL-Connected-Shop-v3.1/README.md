# SPL Connected Shop v3.1

Two linked interfaces share one persistent backend:

- Customer shop: `/` — live catalog, saved products, bag and direct checkout.
- Customer account: `/account/` — sign in/register, view own orders and status history.
- Owner dashboard: `/owner/` — private sign-in, product prices and inventory, photo uploads, visibility, incoming orders and status updates.

Changes are synchronized through the server/database. Catalog, account and dashboard refresh automatically every 15 seconds; explicit Refresh buttons are available. Each customer sees only their own orders. Owners manage the SPL shop.

## Quick start with the included build

Requires Node.js 22.13+ (Node.js LTS recommended). Extract the full ZIP, open a terminal in its folder, and create an owner before exposing the server to other people:

```powershell
npm.cmd run owner:create
npm.cmd start
```

The owner creation command asks for your email, name and password; passwords are masked and must be at least 12 characters. There is no shipped owner password. On macOS/Linux use `npm` instead of `npm.cmd`.

Open http://127.0.0.1:4174/ for the customer shop and http://127.0.0.1:4174/owner/ for the owner dashboard. Customers register through checkout or the account page. Use a separate browser profile/private window to use owner and customer accounts at the same time. START-PREVIEW.cmd starts the same connected server on Windows. The included prebuilt interface and backend use built-in Node.js modules, so no dependency installation is required just to run this build.

The server creates private local state in `data/shop.sqlite`, with uploaded photos in `data/uploads/`. Do not delete data when updating the source. Do not share the database, uploaded private backups, environment files or owner credentials in a ZIP or Git repository.

## Development

```powershell
npm.cmd ci
npm.cmd run dev
```

Development runs the interface at http://127.0.0.1:3000/ and its API at port 3001. The frontend proxies API and upload requests to that backend. Open `/owner/` on port 3000 for the owner view. It uses the same data directory as the quick-start server; stop other instances before switching workflows.

Verify and rebuild:

```sh
npm run typecheck
npm run lint
npm test
npm run build
npm start
```

Node.js 22 may print experimental warnings for SQLite/type stripping; the backend was tested on Node 22.13 and Node 24. The connected build must be hosted at the domain root, with NEXT_PUBLIC_BASE_PATH empty. The build intentionally rejects subfolder deployment.

## Order behavior

Customers sign in before checkout, enter delivery information and review a price quote. The server checks product visibility, prices, quantities and totals. Available stock is reserved atomically when an order is accepted. Duplicate submission retries do not create another order or reserve stock twice. Changed prices or insufficient stock require a new review.

Owners move orders from Pending → Confirmed → Ready → Completed. Pending, Confirmed or Ready orders can be cancelled; cancellation returns stock exactly once. Completed and cancelled orders are final. Status history is available to the customer. Order prices and product names are snapshots and are not rewritten by later catalog edits.

The current dashboard/account show the most recent 200 orders. For a larger order volume, add pagination/export before relying on this as a full historical administration system. Metrics labeled as completed item totals exclude delivery and do not verify payments.

Payment is arranged directly with SPL. The website does not collect card/bank credentials or integrate KPay/bank transfers. There are no payment confirmations, email/SMS notifications, password-account email verification, customer password-reset emails or MFA in this version. Google accounts use Google-verified email and Google's own account protections. Owners need server-console access to provision additional owners. Owner password recovery must be handled by an administrator with database/server access; do not invent a public reset endpoint.

## Hosting and Namecheap

A Namecheap domain can point to a compatible hosting service later. Domain registration alone is not hosting. This version needs a running Node.js 22.13+ process and persistent local disk for SQLite/uploads; uploading only dist/client to public_html, GitHub Pages or a static-only host will not provide working accounts/orders. Check the chosen host's supported Node version and persistent-storage support. Use one application instance on persistent local disk; this is not a distributed serverless database design.

For production:

1. Install tooling/dependencies with `npm ci` and build with `npm run build` if changing source. Set NEXT_PUBLIC_SITE_URL to your actual HTTPS domain before building to generate canonical/social metadata and a sitemap.
2. Put private DATA_DIRECTORY outside the publicly served web root and keep it across deployments. Protect and back it up. Stop the app before copying the complete data folder for a consistent simple backup; live backups require SQLite-aware tooling.
3. Create a password owner account through the server console, or configure approved Google owner access before public exposure. Keep passwords out of source, commands saved in documentation, and chat.
4. Configure NODE_ENV=production, PUBLIC_ORIGIN=https://YOUR-ACTUAL-DOMAIN, HOST=0.0.0.0, and the host's PORT. Run `npm start` under the host's service/process manager.
5. Terminate HTTPS at a trusted reverse proxy; forward requests, uploads and API to this Node service. Redirect HTTP and alternate domains to the configured canonical HTTPS domain. Secure session cookies require HTTPS. Do not publish a local development server.
6. Point the domain's DNS to that host and verify customer registration, checkout, owner access, photo upload and status updates from separate devices. No DNS or live-domain deployment was performed here.

All mutations enforce configured request origins. Authenticated mutations also require a per-session CSRF token. Sessions use HttpOnly/SameSite cookies and Secure cookies in production. Passwords use salted scrypt hashes; authentication tokens are stored hashed. Login/signup attempts are rate-limited. These checks were tested, but this is not a complete independent security audit or a guarantee of production suitability.

## Privacy and shop facts

Delivery names, phone numbers, addresses and notes are now stored on the shop server because they must reach the owner. They are visible to the customer and authorized owners. They are not put in local storage. Set appropriate retention, backup access and deletion procedures before collecting real customer information. Old browser-only request data from v2 remains local and is not silently uploaded to this server.

Verify actual prices, stock, specifications, warranty, contact details and product/photo matches before launch. Third-party photo sources are recorded in ASSET-SOURCES.json. No shop facts or image rights were independently authenticated. Edit the initial shop/catalog in lib/storefront.ts and lib/catalog.ts; subsequent product edits belong in the owner dashboard so they update the database.

See RELEASE-NOTES.md for verification and remaining dependency findings. The GitHub workflow checks the build/tests only; static Pages deployment was removed for the connected application.

## Google customer and owner login

See GOOGLE-SETUP.md for Google OAuth credentials, exact callback URLs, approved owner emails and safe linking of existing password accounts. Google login uses only identity/profile permissions; password login remains available. Google sign-in will remain disabled until the private server configuration is supplied. Existing accounts/orders are preserved when the database is upgraded.

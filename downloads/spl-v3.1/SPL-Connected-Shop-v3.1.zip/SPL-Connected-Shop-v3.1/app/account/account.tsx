'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import { AuthForm } from '@/components/auth-form';
import { GoogleAccount } from '@/components/google-account';
import {
  api,
  errorMessage,
  type Session,
  type ConnectedOrder,
} from '@/lib/connected';
import { money } from '@/lib/storefront';
export default function Account() {
  const [session, setSession] = useState<Session | null>(null);
  const [orders, setOrders] = useState<ConnectedOrder[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      const auth = await api<Session>('/api/auth/session');
      setSession(auth);
      if (auth.user?.role === 'customer') {
        const result = await api<{ orders: ConnectedOrder[] }>('/api/orders');
        setOrders(result.orders);
      }
      setError('');
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    // oxlint-disable-next-line react/react-compiler -- Refresh awaits server responses before setting state.
    void refresh();
    const timer = setInterval(() => void refresh(), 15000);
    return () => clearInterval(timer);
  }, [refresh]);
  return (
    <div className="portal">
      <header className="portal-header">
        <Link className="portal-brand" href="/">
          SHWE PYAE SAN <small>Customer account</small>
        </Link>
        <Link href="/">Back to shop</Link>
      </header>
      <main className="portal-main">
        {loading ? (
          <p>Loading your account…</p>
        ) : !session?.user ? (
          <AuthForm onSignedIn={() => void refresh()} />
        ) : session.user.role === 'owner' ? (
          <section className="auth-card">
            <h1>Owner account</h1>
            <p>Manage the shop through your private dashboard.</p>
            <Link className="portal-primary" href="/owner/">
              Open owner dashboard
            </Link>
            <button
              className="portal-secondary"
              onClick={async () => {
                try {
                  await api('/api/auth/logout', {
                    method: 'POST',
                    csrf: session.csrf,
                  });
                  setSession({ user: null, csrf: null });
                  setOrders([]);
                } catch (e) {
                  setError(errorMessage(e));
                }
              }}
            >
              Sign out
            </button>
          </section>
        ) : (
          <>
            <div className="portal-title">
              <div>
                <span className="eyebrow">YOUR SPL ACCOUNT</span>
                <h1>Hello, {session.user.name}.</h1>
                <p>Your orders and their latest status.</p>
              </div>
              <div className="portal-actions">
                <GoogleAccount session={session} />
                <button
                  className="portal-secondary"
                  onClick={() => void refresh()}
                >
                  Refresh orders
                </button>
                <button
                  className="portal-secondary"
                  onClick={async () => {
                    try {
                      await api('/api/auth/logout', {
                        method: 'POST',
                        csrf: session.csrf,
                      });
                      setSession({ user: null, csrf: null });
                      setOrders([]);
                    } catch (e) {
                      setError(errorMessage(e));
                    }
                  }}
                >
                  Sign out
                </button>
              </div>
            </div>
            {!orders.length ? (
              <section className="portal-card">
                <h2>No orders yet</h2>
                <p>Choose a laptop and place your first order.</p>
                <Link className="portal-primary" href="/">
                  Browse laptops
                </Link>
              </section>
            ) : (
              <div className="portal-orders">
                {orders.map((order) => (
                  <article className="portal-card" key={order.id}>
                    <div className="portal-order-heading">
                      <strong className="order-reference">{order.id}</strong>
                      <span className={`order-status status-${order.status}`}>
                        {order.status}
                      </span>
                    </div>
                    <p>{new Date(order.createdAt).toLocaleString()}</p>
                    <ul className="portal-items">
                      {order.items.map((item) => (
                        <li key={item.id}>
                          <span>
                            {item.quantity} × {item.name}
                          </span>
                          <strong>{money(item.price * item.quantity)}</strong>
                        </li>
                      ))}
                    </ul>
                    <strong>Items total: {money(order.total)}</strong>
                    <p>Delivery and payment: confirm with SPL.</p>
                    <details>
                      <summary>Delivery details and status history</summary>
                      <p>
                        {order.delivery.name}
                        <br />
                        {order.delivery.phone}
                        <br />
                        {order.delivery.address}
                      </p>
                      {order.delivery.note && <p>{order.delivery.note}</p>}
                      <p>{order.payment}</p>
                      <ol>
                        {order.events.map((event, index) => (
                          <li key={index}>
                            {event.status} ·{' '}
                            {new Date(event.createdAt).toLocaleString()}
                          </li>
                        ))}
                      </ol>
                    </details>
                  </article>
                ))}
              </div>
            )}
          </>
        )}
        {error && (
          <div className="portal-error" role="alert">
            {error}
            <button className="portal-link" onClick={() => void refresh()}>
              Try again
            </button>
          </div>
        )}
      </main>
      <footer className="portal-footer">
        SHWE PYAE SAN · Orders are unpaid until confirmed directly with the
        shop.
      </footer>
    </div>
  );
}

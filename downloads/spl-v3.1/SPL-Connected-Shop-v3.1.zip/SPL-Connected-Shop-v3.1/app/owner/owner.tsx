'use client';
import Link from 'next/link';
import { ProductImage } from '@/components/shop-product';
import { useCallback, useEffect, useState } from 'react';
import { AuthForm } from '@/components/auth-form';
import { GoogleAccount } from '@/components/google-account';
import {
  api,
  errorMessage,
  orderTransitions,
  type ConnectedOrder,
  type ManagedProduct,
  type Session,
} from '@/lib/connected';
import { money } from '@/lib/storefront';
const blank: ManagedProduct = {
  id: 0,
  name: '',
  subtitle: '',
  category: 'Business',
  condition: '',
  price: 0,
  stock: 0,
  image: '/products/laptop-1.jpg',
  specs: [''],
  active: true,
  version: 0,
};
export default function Owner() {
  const [session, setSession] = useState<Session | null>(null);
  const [products, setProducts] = useState<ManagedProduct[]>([]);
  const [orders, setOrders] = useState<ConnectedOrder[]>([]);
  const [tab, setTab] = useState<'orders' | 'products'>('orders');
  const [editing, setEditing] = useState<ManagedProduct | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const refresh = useCallback(async () => {
    try {
      const auth = await api<Session>('/api/auth/session');
      setSession(auth);
      if (auth.user?.role === 'owner') {
        const [catalog, received] = await Promise.all([
          api<{ products: ManagedProduct[] }>('/api/owner/products'),
          api<{ orders: ConnectedOrder[] }>('/api/owner/orders'),
        ]);
        setProducts(catalog.products);
        setOrders(received.orders);
      }
      setError('');
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    // oxlint-disable-next-line react/react-compiler -- Refresh awaits server responses before setting state.
    void refresh();
    const timer = setInterval(() => void refresh(), 15000);
    return () => clearInterval(timer);
  }, [refresh]);
  const logout = async () => {
    try {
      await api('/api/auth/logout', { method: 'POST', csrf: session?.csrf });
      setSession({ user: null, csrf: null });
      setProducts([]);
      setOrders([]);
      setEditing(null);
    } catch (e) {
      setError(errorMessage(e));
    }
  };
  const field = (
    key: 'name' | 'subtitle' | 'category' | 'condition' | 'image',
    label: string,
    max: number,
  ) => (
    <label key={key}>
      {label}
      <input
        value={editing?.[key] ?? ''}
        onChange={(e) =>
          setEditing((p) => (p ? { ...p, [key]: e.target.value } : p))
        }
        required
        maxLength={max}
      />
    </label>
  );
  return (
    <div className="portal owner-portal">
      <header className="portal-header">
        <Link href="/owner/" className="portal-brand">
          SHWE PYAE SAN <small>Owner dashboard</small>
        </Link>
        <Link href="/" target="_blank" rel="noreferrer">
          View customer shop ↗
        </Link>
      </header>
      <main className="portal-main">
        {loading ? (
          <p>Loading your shop…</p>
        ) : !session?.user ? (
          <AuthForm owner onSignedIn={() => void refresh()} />
        ) : session.user.role !== 'owner' ? (
          <section className="auth-card">
            <h1>Owner access required</h1>
            <p>This account is a customer account.</p>
            <Link className="portal-primary" href="/account/">
              My customer orders
            </Link>
            <button className="portal-secondary" onClick={() => void logout()}>
              Sign out
            </button>
          </section>
        ) : (
          <>
            <div className="portal-title">
              <div>
                <span className="eyebrow">SHOP MANAGEMENT</span>
                <h1>Your shop, connected.</h1>
                <p>
                  Welcome, {session.user.name}. Customers see your published
                  catalog.
                </p>
              </div>
              <div className="portal-actions">
                <GoogleAccount session={session} owner />
                <button
                  className="portal-secondary"
                  onClick={() => void refresh()}
                >
                  Refresh dashboard
                </button>
                <button
                  className="portal-secondary"
                  onClick={() => void logout()}
                >
                  Sign out
                </button>
              </div>
            </div>
            <div className="portal-stats">
              <article>
                <span>Awaiting confirmation</span>
                <strong>
                  {orders.filter((o) => o.status === 'pending').length}
                </strong>
              </article>
              <article>
                <span>Active products</span>
                <strong>{products.filter((p) => p.active).length}</strong>
              </article>
              <article>
                <span>Low stock (2 or fewer)</span>
                <strong>
                  {products.filter((p) => p.active && p.stock <= 2).length}
                </strong>
              </article>
              <article>
                <span>Completed items total</span>
                <strong>
                  {money(
                    orders
                      .filter((o) => o.status === 'completed')
                      .reduce((sum, o) => sum + o.total, 0),
                  )}
                </strong>
                <small>Latest 200 orders · excludes delivery</small>
              </article>
            </div>
            <nav className="portal-tabs" aria-label="Dashboard sections">
              <button
                aria-pressed={tab === 'orders'}
                onClick={() => {
                  setTab('orders');
                  setError('');
                }}
              >
                Orders
              </button>
              <button
                aria-pressed={tab === 'products'}
                onClick={() => {
                  setTab('products');
                  setError('');
                }}
              >
                Products & inventory
              </button>
            </nav>
            {notice && <output className="portal-success">{notice}</output>}
            {tab === 'orders' ? (
              <>
                <div className="portal-section-title">
                  <h2>Customer orders</h2>
                  <label>
                    Filter status
                    <select
                      value={filter}
                      onChange={(e) => setFilter(e.target.value)}
                    >
                      {[
                        'all',
                        'pending',
                        'confirmed',
                        'ready',
                        'completed',
                        'cancelled',
                      ].map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </label>
                </div>
                <div className="portal-orders">
                  {orders
                    .filter((o) => filter === 'all' || o.status === filter)
                    .map((order) => (
                      <article
                        className="portal-card"
                        key={`${order.id}-${order.version}`}
                      >
                        <div className="portal-order-heading">
                          <strong className="order-reference">
                            {order.id}
                          </strong>
                          <span
                            className={`order-status status-${order.status}`}
                          >
                            {order.status}
                          </span>
                        </div>
                        <p>
                          {new Date(order.createdAt).toLocaleString()} ·{' '}
                          {order.customerName} · {order.customerEmail}
                        </p>
                        <ul className="portal-items">
                          {order.items.map((item) => (
                            <li key={item.id}>
                              <span>
                                {item.quantity} × {item.name}
                              </span>
                              <strong>
                                {money(item.price * item.quantity)}
                              </strong>
                            </li>
                          ))}
                        </ul>
                        <strong>Items total: {money(order.total)}</strong>
                        <details>
                          <summary>Contact, delivery and history</summary>
                          <p>
                            {order.delivery.name}
                            <br />
                            <a href={`tel:${order.delivery.phone}`}>
                              {order.delivery.phone}
                            </a>
                            <br />
                            {order.delivery.address}
                          </p>
                          {order.delivery.note && <p>{order.delivery.note}</p>}
                          <p>
                            Payment preference: {order.payment} · no online
                            payment collected.
                          </p>
                          <ol>
                            {order.events.map((event, i) => (
                              <li key={i}>
                                {event.status} ·{' '}
                                {new Date(event.createdAt).toLocaleString()}
                              </li>
                            ))}
                          </ol>
                        </details>
                        {orderTransitions[order.status].length > 0 && (
                          <form
                            className="portal-actions order-update"
                            onSubmit={async (e) => {
                              e.preventDefault();
                              if (busy) return;
                              const choice = new FormData(e.currentTarget).get(
                                'status',
                              );
                              if (typeof choice !== 'string') return;
                              const status = choice;
                              if (
                                status === 'cancelled' &&
                                !window.confirm(
                                  'Cancel this order and return its items to available stock?',
                                )
                              )
                                return;
                              setBusy(true);
                              setError('');
                              try {
                                await api(`/api/owner/orders/${order.id}`, {
                                  method: 'PUT',
                                  csrf: session.csrf,
                                  body: { status, version: order.version },
                                });
                                setNotice(
                                  'Order updated. The customer can see the new status.',
                                );
                                await refresh();
                              } catch (err) {
                                setError(errorMessage(err));
                              } finally {
                                setBusy(false);
                              }
                            }}
                          >
                            <label>
                              Next status
                              <select
                                name="status"
                                aria-label={`Next status for ${order.id}`}
                              >
                                {orderTransitions[order.status].map((s) => (
                                  <option key={s}>{s}</option>
                                ))}
                              </select>
                            </label>
                            <button className="portal-primary" disabled={busy}>
                              Update order
                            </button>
                          </form>
                        )}
                      </article>
                    ))}
                  {!orders.filter(
                    (o) => filter === 'all' || o.status === filter,
                  ).length && (
                    <section className="portal-card">
                      <h3>No orders in this view</h3>
                      <p>
                        Orders submitted from the customer shop will appear
                        here.
                      </p>
                    </section>
                  )}
                </div>
              </>
            ) : (
              <div className="inventory-layout">
                <section>
                  <div className="portal-section-title">
                    <h2>Product catalog</h2>
                    <button
                      className="portal-primary"
                      onClick={() => {
                        setEditing({ ...blank, specs: [''] });
                        setNotice('');
                        setError('');
                      }}
                    >
                      Add product
                    </button>
                  </div>
                  <div className="inventory-list">
                    {products.map((product) => (
                      <article className="inventory-product" key={product.id}>
                        <ProductImage product={product} />
                        <div>
                          <h3>{product.name}</h3>
                          <p>
                            {money(product.price)} · {product.stock} available
                          </p>
                          <span
                            className={`order-status ${product.active ? 'status-confirmed' : 'status-cancelled'}`}
                          >
                            {product.active ? 'Visible' : 'Hidden'}
                          </span>
                        </div>
                        <button
                          className="portal-secondary"
                          aria-label={`Edit ${product.name}`}
                          onClick={() => {
                            setEditing({
                              ...product,
                              specs: [...product.specs],
                            });
                            setError('');
                            setNotice('');
                          }}
                        >
                          Edit
                        </button>
                      </article>
                    ))}
                  </div>
                </section>
                <section className="portal-card product-editor">
                  {!editing ? (
                    <>
                      <h2>Edit your catalog</h2>
                      <p>
                        Choose a product or add a new one. Hidden products are
                        not offered to customers. Existing orders retain their
                        original product and price snapshots.
                      </p>
                    </>
                  ) : (
                    <form
                      className="portal-form"
                      onSubmit={async (e) => {
                        e.preventDefault();
                        if (busy) return;
                        setBusy(true);
                        setError('');
                        try {
                          await api(
                            editing.id
                              ? `/api/owner/products/${editing.id}`
                              : '/api/owner/products',
                            {
                              method: editing.id ? 'PUT' : 'POST',
                              csrf: session.csrf,
                              body: editing,
                            },
                          );
                          setEditing(null);
                          setNotice(
                            'Product saved. Customer catalog updates automatically within 15 seconds.',
                          );
                          await refresh();
                        } catch (err) {
                          setError(errorMessage(err));
                        } finally {
                          setBusy(false);
                        }
                      }}
                    >
                      <h2>{editing.id ? 'Edit product' : 'New product'}</h2>
                      {field('name', 'Product name', 120)}
                      {field('subtitle', 'Subtitle', 180)}
                      {field('category', 'Category', 40)}
                      {field('condition', 'Condition', 100)}
                      <div className="portal-two-columns">
                        <label>
                          Price (Ks)
                          <input
                            type="number"
                            min="1"
                            max="1000000000000"
                            step="1"
                            value={editing.price || ''}
                            onChange={(e) =>
                              setEditing((p) =>
                                p ? { ...p, price: Number(e.target.value) } : p,
                              )
                            }
                            required
                          />
                        </label>
                        <label>
                          Available stock
                          <input
                            type="number"
                            min="0"
                            max="1000000"
                            step="1"
                            value={editing.stock}
                            onChange={(e) =>
                              setEditing((p) =>
                                p ? { ...p, stock: Number(e.target.value) } : p,
                              )
                            }
                            required
                          />
                        </label>
                      </div>
                      <label>
                        Previous price (optional)
                        <input
                          type="number"
                          min={editing.price + 1}
                          step="1"
                          value={editing.oldPrice ?? ''}
                          onChange={(e) =>
                            setEditing((p) =>
                              p
                                ? {
                                    ...p,
                                    oldPrice: e.target.value
                                      ? Number(e.target.value)
                                      : undefined,
                                  }
                                : p,
                            )
                          }
                        />
                      </label>
                      <label>
                        Specifications (one per line)
                        <textarea
                          rows={5}
                          value={editing.specs.join('\n')}
                          onChange={(e) =>
                            setEditing((p) =>
                              p
                                ? { ...p, specs: e.target.value.split('\n') }
                                : p,
                            )
                          }
                          required
                        />
                      </label>
                      {field('image', 'Image path', 250)}
                      <label>
                        Upload product photo (JPG, PNG, WebP · max 3 MB)
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          disabled={busy}
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            if (file.size > 3 * 1024 * 1024) {
                              setError('Choose an image up to 3 MB.');
                              return;
                            }
                            setBusy(true);
                            setError('');
                            try {
                              const response = await fetch(
                                '/api/owner/images',
                                {
                                  method: 'POST',
                                  credentials: 'same-origin',
                                  headers: {
                                    'Content-Type': file.type,
                                    'X-CSRF-Token': session.csrf ?? '',
                                  },
                                  body: file,
                                },
                              );
                              const result = await response.json();
                              if (!response.ok) throw new Error(result.error);
                              setEditing((p) =>
                                p ? { ...p, image: result.image } : p,
                              );
                              setNotice(
                                'Photo uploaded. Save the product to publish it.',
                              );
                            } catch (err) {
                              setError(errorMessage(err));
                            } finally {
                              setBusy(false);
                            }
                          }}
                        />
                      </label>
                      <label className="portal-checkbox">
                        <input
                          type="checkbox"
                          checked={editing.active}
                          onChange={(e) =>
                            setEditing((p) =>
                              p ? { ...p, active: e.target.checked } : p,
                            )
                          }
                        />
                        Visible in customer shop
                      </label>
                      <p className="portal-muted">
                        Stock is the number available after current
                        reservations. If a new order changes this product while
                        you edit, reload it before saving.
                      </p>
                      <div className="portal-actions">
                        <button className="portal-primary" disabled={busy}>
                          {busy ? 'Saving…' : 'Save product'}
                        </button>
                        <button
                          type="button"
                          className="portal-secondary"
                          onClick={() => setEditing(null)}
                          disabled={busy}
                        >
                          Cancel edit
                        </button>
                      </div>
                    </form>
                  )}
                </section>
              </div>
            )}
          </>
        )}
        {error && (
          <p className="portal-error" role="alert">
            {error}
          </p>
        )}
      </main>
      <footer className="portal-footer">
        Private owner area · Customer changes and orders share one database.
      </footer>
    </div>
  );
}

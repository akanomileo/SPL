'use client';
import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  LogOut,
  RefreshCw,
  ShoppingBag,
  Check,
} from 'lucide-react';
import { AuthForm } from '@/components/auth-form';
import { OrderPayment } from '@/components/payment-instructions';
import { orderLabels } from '@/components/owner-order';
import {
  api,
  errorMessage,
  type Session,
  type ConnectedOrder,
} from '@/lib/connected';
import { money } from '@/lib/storefront';
function OrderProgress({ status }: { status: string }) {
  const steps = ['pending', 'confirmed', 'ready', 'completed'];
  const current = steps.indexOf(status);
  if (status === 'cancelled') return null;
  return (
    <ol className="order-progress" aria-label="Order progress">
      {steps.map((step, index) => (
        <li
          key={step}
          className={index <= current ? 'is-reached' : ''}
          aria-current={index === current ? 'step' : undefined}
        >
          <span>
            {index < current ? (
              <Check size={12} aria-hidden="true" />
            ) : (
              index + 1
            )}
          </span>
          {orderLabels[step]}
        </li>
      ))}
    </ol>
  );
}
export default function Account() {
  const [session, setSession] = useState<Session | null>(null);
  const [orders, setOrders] = useState<ConnectedOrder[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const refresh = useCallback(async () => {
    try {
      const auth = await api<Session>('/api/auth/session');
      setSession(auth);
      if (auth.user?.role === 'customer') {
        const result = await api<{ orders: ConnectedOrder[] }>('/api/orders');
        setOrders(result.orders);
      } else setOrders([]);
      setError('');
    } catch (cause) {
      setError(errorMessage(cause));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    // oxlint-disable-next-line react/react-compiler -- Refresh awaits server responses before setting state.
    void refresh();
    const timer = setInterval(() => void refresh(), 15000);
    const focus = () => void refresh();
    window.addEventListener('focus', focus);
    return () => {
      clearInterval(timer);
      window.removeEventListener('focus', focus);
    };
  }, [refresh]);
  const logout = async () => {
    try {
      await api('/api/auth/logout', { method: 'POST', csrf: session?.csrf });
      setSession({ user: null, csrf: null });
      setOrders([]);
    } catch (cause) {
      setError(errorMessage(cause));
    }
  };
  return (
    <div className="portal customer-portal">
      <header className="portal-header">
        <Link className="portal-brand" href="/">
          SHWE PYAE SAN<small>My account</small>
        </Link>
        <Link className="portal-header-link" href="/">
          <ArrowLeft size={16} aria-hidden="true" />
          Back to shop
        </Link>
      </header>
      <main className="portal-main">
        {loading ? (
          <output className="portal-loading">
            <span className="portal-loading-dot" />
            Loading your orders…
          </output>
        ) : !session?.user ? (
          <AuthForm onSignedIn={() => void refresh()} />
        ) : session.user.role === 'owner' ? (
          <section className="auth-card">
            <h1>Owner account</h1>
            <p>Open the dashboard to manage your shop.</p>
            <Link className="portal-primary" href="/owner/">
              Open owner dashboard
            </Link>
            <button className="portal-secondary" onClick={() => void logout()}>
              Sign out
            </button>
          </section>
        ) : (
          <>
            <div className="portal-title">
              <div>
                <span className="eyebrow">MY ACCOUNT</span>
                <h1>My orders</h1>
                <p>
                  Hi, {session.user.name}. Payment updates and delivery progress
                  are here.
                </p>
              </div>
              <div className="portal-actions">
                <button
                  className="portal-secondary"
                  onClick={() => void refresh()}
                >
                  <RefreshCw size={16} aria-hidden="true" />
                  Refresh
                </button>
                <button
                  className="portal-secondary"
                  onClick={() => void logout()}
                >
                  <LogOut size={16} aria-hidden="true" />
                  Sign out
                </button>
              </div>
            </div>
            {!orders.length ? (
              <section className="portal-card portal-empty">
                <span className="portal-icon">
                  <ShoppingBag size={30} aria-hidden="true" />
                </span>
                <h2>Your first order starts here</h2>
                <p>
                  Browse the shop, choose what you like, and we’ll keep your
                  order updates here.
                </p>
                <Link className="portal-primary" href="/">
                  Browse the shop
                  <ArrowRight size={16} aria-hidden="true" />
                </Link>
              </section>
            ) : (
              <div className="portal-orders customer-orders">
                {orders.map((order) => (
                  <article className="portal-card" key={order.id}>
                    <div className="portal-order-heading">
                      <div>
                        <span className="order-small-label">ORDER</span>
                        <strong className="order-reference">{order.id}</strong>
                      </div>
                      <span className={`order-status status-${order.status}`}>
                        {orderLabels[order.status] ?? order.status}
                      </span>
                    </div>
                    <p className="portal-muted">
                      Placed {new Date(order.createdAt).toLocaleString()}
                    </p>
                    <OrderProgress status={order.status} />
                    <ul className="portal-items">
                      {order.items.map((item) => (
                        <li key={item.id}>
                          <span>
                            {item.quantity} × {item.name}
                          </span>
                          <strong>{money(item.price * item.quantity)}</strong>
                        </li>
                      ))}
                    </ul>
                    <div className="order-total">
                      <span>Items total</span>
                      <strong>{money(order.total)}</strong>
                    </div>
                    <OrderPayment
                      order={order}
                      csrf={session.csrf}
                      onUpdated={(updated) =>
                        setOrders((previous) =>
                          previous.map((existing) =>
                            existing.id === updated.id ? updated : existing,
                          ),
                        )
                      }
                    />
                    <details>
                      <summary>Delivery details & order history</summary>
                      <p>
                        {order.delivery.name}
                        <br />
                        {order.delivery.phone}
                        <br />
                        {order.delivery.address}
                      </p>
                      {order.delivery.note && <p>{order.delivery.note}</p>}
                      <ol>
                        {order.events.map((event, index) => (
                          <li key={index}>
                            {orderLabels[event.status] ??
                              event.status.replaceAll('_', ' ')}{' '}
                            · {new Date(event.createdAt).toLocaleString()}
                          </li>
                        ))}
                      </ol>
                    </details>
                  </article>
                ))}
              </div>
            )}
          </>
        )}
        {error && (
          <div className="portal-error" role="alert">
            {error}
            <button className="portal-link" onClick={() => void refresh()}>
              Try again
            </button>
          </div>
        )}
      </main>
      <footer className="portal-footer">
        SHWE PYAE SAN · Thank you for shopping with us.
      </footer>
    </div>
  );
}
